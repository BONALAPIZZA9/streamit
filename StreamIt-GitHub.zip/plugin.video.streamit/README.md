# StreamIt 1.6.0

## Installazione
In Kodi: Add-on → Installa da file ZIP → StreamIt-1.6.0.zip.
Richiede Kodi 19+ e i moduli requests e beautifulsoup4.

## Uso
Il menu contiene Film, Serie, Cerca, Generi, Siti e Gestione.
Scegli la fonte da Siti: CB01 è disponibile anche aggiornando una vecchia installazione.
Gestione raccoglie aggiornamento catalogo, aggiunta/modifica siti, verifica e impostazioni.
Il nuovo logo è incluso nel pacchetto.

## Compatibilità
- StreamingCommunity: catalogo, ricerca, generi, stagioni e playlist del player.
- CB01: catalogo film/serie, ricerca film, generi, paginazione e stagioni/episodi
  con collegamenti pubblicati nel formato stagione×episodio. Le raccolte esterne
  senza elenco episodi nella scheda non vengono indicizzate.
- Pagine HTML con video diretti.

CB01 usa lettori esterni: scegli il collegamento nella finestra Scegli lettore.
Se ResolveURL è già disponibile, viene usato per gli host che riconosce.
La riproduzione non è garantita: nel controllo effettuato uprot.net rispondeva
HTTP 403. Non vengono aggirati blocchi, autenticazione o protezioni.
Catalogo, paginazione, ricerca, generi e collegamenti episodio CB01 verificati online.
Riproduzione effettiva dentro Kodi non verificata.

## Aggiornamento e immagini
Aggiorna catalogo ricarica film, serie, generi e la prima pagina di ogni genere
per il sito selezionato; le altre pagine vengono caricate all'apertura.
La cache separata per fonte scade dopo 10 minuti.
Locandine, copertine e sfondi mantengono la risoluzione fornita dal sito.

## Test
python -m unittest discover -s tests -v

## Icone 1.6.0
29 icone locali per menu, gestione, navigazione e generi. Le locandine dei contenuti restano prioritarie. La dimensione visualizzata dipende dalla skin Kodi.
