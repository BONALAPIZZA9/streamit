# -*- coding: utf-8 -*-
"""
StreamIt - Addon Kodi per Film e Serie TV
Punto di ingresso principale dell'addon.
"""
import sys
from urllib.parse import parse_qsl

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.navigation import Navigator

# ID del plugin e handle Kodi
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]


def main():
    """Funzione principale: analizza i parametri URL e naviga."""
    # Estrai i parametri dalla query string (sys.argv[2])
    params = dict(parse_qsl(sys.argv[2].lstrip('?')))

    navigator = Navigator(HANDLE, BASE_URL, ADDON, params.get('source'))

    action = params.get('action', 'home')

    if action == 'home':
        from resources.lib.audio import choose_language
        if not choose_language():
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
        navigator.show_home()
    elif action == 'iptv':
        navigator.show_iptv()
    elif action == 'play_iptv':
        navigator.play_iptv(params.get('channel', ''))
    elif action == 'manage':
        navigator.show_manage()
    elif action == 'sources':
        navigator.show_sources()
    elif action == 'detect_source':
        navigator.detect_source()
    elif action == 'add_source':
        navigator.edit_source(adding=True)
    elif action == 'edit_source':
        navigator.edit_source()
    elif action == 'refresh_all':
        navigator.refresh_all()
    elif action == 'settings':
        navigator.show_settings()
    elif action == 'search':
        navigator.show_search()
    elif action == 'search_results':
        navigator.show_search_results(params.get('query', ''))
    elif action == 'movies':
        navigator.show_movies(page=max(1, int(params.get('page', 1))))
    elif action == 'series':
        navigator.show_series(page=max(1, int(params.get('page', 1))))
    elif action == 'genres':
        navigator.show_genres()
    elif action == 'genre_content':
        navigator.show_genre_content(
            genre=params.get('genre', ''),
            content_type=params.get('content_type', 'movies'),
            page=max(1, int(params.get('page', 1)))
        )
    elif action == 'seasons':
        navigator.show_seasons(
            series_url=params.get('url', ''),
            series_title=params.get('title', '')
        )
    elif action == 'episodes':
        navigator.show_episodes(
            series_url=params.get('url', ''),
            season=int(params.get('season', 1)),
            series_title=params.get('title', '')
        )
    elif action == 'play':
        navigator.play_content(
            url=params.get('url', ''),
            title=params.get('title', ''),
            thumbnail=params.get('thumbnail', '')
        )
    else:
        navigator.show_home()


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        xbmc.log('[StreamIt] Errore: ' + type(exc).__name__, xbmc.LOGERROR)
        message = str(exc) if isinstance(exc, (ValueError, RuntimeError)) else 'Errore inatteso. Consulta il log di Kodi.'
        xbmcgui.Dialog().ok('StreamIt - Errore', message)
        params = dict(parse_qsl(sys.argv[2].lstrip('?')))
        if params.get('action') in ('play', 'play_iptv'):
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        else:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
