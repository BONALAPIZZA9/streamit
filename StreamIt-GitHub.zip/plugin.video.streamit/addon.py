# -*- coding: utf-8 -*-
"""
StreamIt - Addon Kodi per Film e Serie TV
Punto di ingresso principale dell'addon.
"""
import sys
from urllib.parse import parse_qsl

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.navigation import Navigator

# ID del plugin e handle Kodi
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]


def main():
    """Funzione principale: analizza i parametri URL e naviga."""
    # Estrai i parametri dalla query string (sys.argv[2])
    params = dict(parse_qsl(sys.argv[2].lstrip('?')))

    navigator = Navigator(HANDLE, BASE_URL, ADDON, params.get('source'))

    action = params.get('action', 'home')

    if action == 'home':
        navigator.show_home()
    elif action == 'iptv_password':
        from resources.lib.iptv_access import change_password
        change_password()
    elif action == 'iptv':
        navigator.show_iptv(params.get('playlist', 'italia'), page=max(1, int(params.get('page', 1))),
                            view=params.get('view', 'home'), group=params.get('group', ''), query=params.get('query', ''))
    elif action == 'iptv_favorite':
        navigator.toggle_iptv_favorite(params.get('playlist', 'italia'), params.get('key', ''))
    elif action == 'iptv_guide':
        navigator.show_channel_guide(params.get('playlist', 'italia'), params.get('key', ''))
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == 'diagnostics':
        navigator.show_diagnostics()
        if HANDLE >= 0:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == 'play_iptv':
        navigator.play_iptv(params.get('channel', ''), params.get('playlist', 'italia'), params.get('key', ''))
    elif action == 'manage':
        navigator.show_manage()
    elif action == 'refresh_all':
        navigator.refresh_all()
    elif action == 'settings':
        navigator.show_settings()
    elif action == 'search':
        navigator.show_search(params.get('kind'))
    elif action == 'search_results':
        navigator.show_search_results(params.get('query', ''), params.get('kind', 'movie'), max(1, int(params.get('page', 1))))
    elif action == 'actor_content':
        navigator.show_actor_content(params.get('actor', ''), params.get('title', ''), params.get('kind'), max(1, int(params.get('page', 1))))
    elif action == 'movies':
        navigator.show_movies(page=max(1, int(params.get('page', 1))))
    elif action == 'series':
        navigator.show_series(page=max(1, int(params.get('page', 1))))
    elif action == 'genres':
        navigator.show_genres(params.get('kind'))
    elif action == 'genre_content':
        navigator.show_genre_content(
            genre=params.get('genre', ''),
            content_type=params.get('content_type', 'movies'),
            page=max(1, int(params.get('page', 1)))
        )
    elif action == 'seasons':
        navigator.show_seasons(
            series_url=params.get('url', ''),
            series_title=params.get('title', '')
        )
    elif action == 'episodes':
        navigator.show_episodes(
            series_url=params.get('url', ''),
            season=int(params.get('season', 1)),
            series_title=params.get('title', '')
        )
    elif action == 'film_players':
        navigator.show_movies()
    elif action == 'external_player':
        navigator.open_external(params.get('url', ''))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    elif action == 'play':
        navigator.play_content(
            url=params.get('url', ''),
            title=params.get('title', ''),
            thumbnail=params.get('thumbnail', ''),
            candidates=params.get('candidates', ''), direct=params.get('direct') == 'true'
        )
    else:
        navigator.show_home()


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        import traceback
        import requests
        frame = traceback.extract_tb(exc.__traceback__)[-1]
        xbmc.log('[StreamIt] Errore: ' + type(exc).__name__ + ' in ' + frame.name + ':' + str(frame.lineno), xbmc.LOGERROR)
        if isinstance(exc, requests.Timeout):
            message = 'Il servizio impiega troppo tempo a rispondere. Riprova tra poco.'
        elif isinstance(exc, requests.ConnectionError):
            message = 'Connessione al servizio non riuscita. Verifica la rete e riprova.'
        elif isinstance(exc, (ValueError, RuntimeError)):
            message = str(exc)
        else:
            message = 'Operazione non riuscita. Aggiorna StreamIt e apri Gestione → Diagnostica.'
        xbmcgui.Dialog().ok('StreamIt - Errore', message)
        params = dict(parse_qsl(sys.argv[2].lstrip('?')))
        if params.get('action') in ('play', 'play_iptv'):
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        else:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
