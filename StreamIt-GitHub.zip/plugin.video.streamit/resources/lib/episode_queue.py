"""Build playable episode URLs without resolving every stream in advance."""
def playlist_items(episodes, start, auto_next, build_url):
    if start < 0 or start >= len(episodes):
        return []
    selected = episodes[start:] if auto_next else episodes[start:start + 1]
    return [(build_url(action='play', url=ep['url'], title=ep['title'],
                       thumbnail=ep.get('thumbnail', '')), ep) for ep in selected]
