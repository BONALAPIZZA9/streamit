"""Distinguish resolver failure without replacing DNS or TLS verification."""
import socket


def dns_failure(error):
    pending, seen = [error], set()
    while pending:
        item = pending.pop()
        if id(item) in seen:
            continue
        seen.add(id(item))
        if isinstance(item, socket.gaierror) or type(item).__name__ == 'NameResolutionError':
            return True
        for value in (getattr(item, '__cause__', None), getattr(item, '__context__', None),
                      getattr(item, 'reason', None)):
            if isinstance(value, BaseException):
                pending.append(value)
        pending.extend(value for value in getattr(item, 'args', ()) if isinstance(value, BaseException))
    return False
