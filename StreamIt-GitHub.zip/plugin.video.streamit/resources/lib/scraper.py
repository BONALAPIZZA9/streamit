# -*- coding: utf-8 -*-
"""
Modulo di scraping per siti tipo Altadefinizione.
Gestisce recupero e parsing delle pagine HTML.

NOTA: I selettori CSS/XPath qui sono ESEMPI GENERICI.
Dovrai adattarli al sito specifico che vuoi usare,
ispezionando il suo HTML con il browser (F12 → Inspector).
"""
from __future__ import annotations

import re
from urllib.parse import urljoin, urlparse
import requests
from bs4 import BeautifulSoup
from resources.lib import streamingcommunity as sc
from resources.lib import cb01
from resources.lib.artwork import best_image
from resources.lib.network import dns_failure
from resources.lib.detection import detect, MediaProvider

import xbmc

# ─── CONFIGURAZIONE ────────────────────────────────────────────────────────────
# Cambia BASE_URL con il dominio attuale del sito che vuoi usare.
BASE_URL = 'https://streamingcommunityz.rip'  # ← AGGIORNA CON IL DOMINIO CORRENTE

HEADERS = {
    'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/124.0.0.0 Safari/537.36'
    ),
    'Accept-Language': 'it-IT,it;q=0.9',
    'Referer': BASE_URL,
}

SESSION = requests.Session()
SESSION.headers.update(HEADERS)
TIMEOUT = 15
DEBUG = False
DETECTED_PROVIDER = None


def configure(addon, source=None):
    """Applica le impostazioni salvate in Kodi."""
    global BASE_URL, TIMEOUT, DEBUG, DETECTED_PROVIDER
    base = (source or addon.getSetting('base_url') or BASE_URL).strip().rstrip('/')
    if urlparse(base).scheme not in ('http', 'https') or not urlparse(base).netloc:
        raise ValueError('Configura un URL HTTP o HTTPS valido nelle impostazioni.')
    BASE_URL = base
    DETECTED_PROVIDER = None
    try:
        TIMEOUT = max(5, min(60, int(addon.getSetting('timeout') or 15)))
    except ValueError:
        TIMEOUT = 15
    DEBUG = addon.getSetting('debug_log') == 'true'
    SESSION.headers.update({'Referer': BASE_URL + '/',
                            'User-Agent': addon.getSetting('user_agent') or HEADERS['User-Agent']})


def _provider():
    global DETECTED_PROVIDER
    if DETECTED_PROVIDER is not None:
        return DETECTED_PROVIDER
    soup = _get_soup(BASE_URL)
    kind = detect(soup)
    final_url = getattr(soup, '_streamit_url', None) or BASE_URL
    if kind == 'streamingcommunity':
        parsed = urlparse(final_url)
        DETECTED_PROVIDER = sc.Provider(parsed.scheme + '://' + parsed.netloc, _get_soup)
    elif kind == 'cb01':
        parsed = urlparse(final_url)
        DETECTED_PROVIDER = cb01.Provider(parsed.scheme + '://' + parsed.netloc, _get_soup)
    elif kind == 'html_video':
        DETECTED_PROVIDER = MediaProvider(final_url, soup)
    else:
        raise RuntimeError('Sito non riconosciuto: serve un adattatore specifico. Non è un errore della connessione.')
    return DETECTED_PROVIDER


def source_type():
    provider = _provider()
    if isinstance(provider, cb01.Provider):
        return 'CB01: catalogo e collegamenti esterni'
    if isinstance(provider, sc.Provider):
        return 'Catalogo StreamingCommunity: film, serie, ricerca e generi'
    return 'Pagina con video diretti: elenco e ricerca nei video della pagina'



def _absolute(url, base=None):
    if not url or url.startswith(('#', 'javascript:', 'data:')):
        return ''
    result = urljoin(base or BASE_URL + '/', url)
    return result if urlparse(result).scheme in ('http', 'https') else ''


def _debug(message):
    if DEBUG:
        xbmc.log(message, xbmc.LOGDEBUG)

# ───────────────────────────────────────────────────────────────────────────────


def _get_soup(url: str, params: dict = None) -> BeautifulSoup | None:
    """Scarica una pagina e la analizza con BeautifulSoup."""
    try:
        _debug('[StreamIt] Recupero pagina')
        response = SESSION.get(url, params=params, timeout=TIMEOUT)
        response.raise_for_status()
        response.encoding = response.encoding if response.encoding and response.encoding.lower() != 'iso-8859-1' else 'utf-8'
        soup = BeautifulSoup(response.text, 'html.parser')
        soup._streamit_url = response.url
        return soup
    except requests.RequestException as e:
        status = e.response.status_code if e.response is not None else None
        host = urlparse(url).hostname or 'sito'
        xbmc.log('[StreamIt] %s: %s HTTP %s' % (host, type(e).__name__, status), xbmc.LOGERROR)
        if status == 404:
            message = 'Pagina non trovata (HTTP 404). Percorso del sito non supportato.'
        elif status in (401, 403):
            message = 'Il sito rifiuta la richiesta (HTTP %s). Accesso richiesto o limitato.' % status
        elif status:
            message = 'Il sito ha restituito un errore HTTP %s.' % status
        elif dns_failure(e):
            message = 'Il DNS della rete non riesce a risolvere questo dominio. Verifica l’indirizzo del sito e le impostazioni DNS della connessione.'
        elif isinstance(e, requests.exceptions.SSLError):
            message = 'Certificato HTTPS non valido o non verificabile. Controlla data del dispositivo e certificato del sito.'
        elif isinstance(e, requests.Timeout):
            message = 'Il sito non risponde entro il timeout configurato.'
        else:
            message = 'Connessione al sito non riuscita. Verifica dominio e rete.'
        raise RuntimeError(host + ': ' + message) from e


def _best_image(img):
    return best_image(img, BASE_URL)


def _parse_card(card) -> dict | None:
    """
    Estrae i dati da una card/elemento di un film o serie.
    ⚠️  I selettori CSS qui DEVONO essere adattati al sito target.
    """
    try:
        # Titolo
        title_tag = card.select_one('.card-title, h2, .title, a[title]')
        title = (title_tag.get_text(strip=True) or title_tag.get('title', 'Titolo sconosciuto')) if title_tag else 'Titolo sconosciuto'

        # URL della pagina del contenuto
        link_tag = card.select_one('a[href]')
        url = link_tag['href'] if link_tag else ''
        url = _absolute(url)

        # Thumbnail/poster
        img_tag = card.select_one('img')
        thumbnail = ''
        if img_tag:
            thumbnail = _best_image(img_tag)

        # Anno (opzionale)
        year_tag = card.select_one('.year, .anno, [class*="year"]')
        year = year_tag.get_text(strip=True) if year_tag else ''

        # Tipo di contenuto (film o serie)
        content_type = 'series' if card.select_one('.serie, [class*="serie"]') else 'movie'

        if not url:
            return None

        return {
            'title': title,
            'url': url,
            'thumbnail': thumbnail,
            'year': year,
            'type': content_type,
        }
    except Exception as e:
        xbmc.log(f'[StreamIt] Errore parsing card: {e}', xbmc.LOGWARNING)
        return None


# ─── API PUBBLICA ───────────────────────────────────────────────────────────────

def search(query: str) -> list[dict]:
    """Cerca contenuti per titolo."""
    provider = _provider()
    if provider:
        return provider.catalog(query=query)[0]
    # La maggior parte dei siti usa ?s=query o /search?q=query
    search_url = f'{BASE_URL}/?s={requests.utils.quote(query)}'
    soup = _get_soup(search_url)
    if not soup:
        return []

    results = []
    # ⚠️ Adatta questo selettore ai card/articoli del sito
    cards = soup.select('article, .film-item, .movie-item, .result-item, li.item')
    for card in cards:
        item = _parse_card(card)
        if item:
            results.append(item)

    xbmc.log(f'[StreamIt] Ricerca "{query}": {len(results)} risultati', xbmc.LOGDEBUG)
    return results


def get_movies(page: int = 1) -> tuple[list[dict], bool]:
    """Recupera la lista dei film. Restituisce (items, has_next_page)."""
    provider = _provider()
    if provider:
        return provider.catalog(page, kind='movie')
    url = f'{BASE_URL}/film/page/{page}/'
    soup = _get_soup(url)
    if not soup:
        return [], False

    items = []
    # ⚠️ Adatta il selettore
    cards = soup.select('article, .film-item, .movie-item, li.item')
    for card in cards:
        item = _parse_card(card)
        if item:
            item['type'] = 'movie'
            items.append(item)

    # Verifica se esiste la pagina successiva
    next_page = soup.select_one('a.next, .pagination .next, a[rel="next"]')
    has_next = next_page is not None

    return items, has_next


def get_series(page: int = 1) -> tuple[list[dict], bool]:
    """Recupera la lista delle serie TV."""
    provider = _provider()
    if provider:
        return provider.catalog(page, kind='tv')
    url = f'{BASE_URL}/serie-tv/page/{page}/'
    soup = _get_soup(url)
    if not soup:
        return [], False

    items = []
    cards = soup.select('article, .film-item, .serie-item, li.item')
    for card in cards:
        item = _parse_card(card)
        if item:
            item['type'] = 'series'
            items.append(item)

    next_page = soup.select_one('a.next, .pagination .next, a[rel="next"]')
    has_next = next_page is not None

    return items, has_next


def get_genres() -> list[dict]:
    """Recupera la lista dei generi disponibili."""
    provider = _provider()
    if provider:
        return provider.genres()
    soup = _get_soup(BASE_URL)
    if not soup:
        return []

    genres = []
    # ⚠️ Adatta il selettore al menu generi del sito
    genre_links = soup.select('ul.genres a, nav .genre-menu a, .cat-item a')
    for link in genre_links:
        name = link.get_text(strip=True)
        href = link.get('href', '')
        if name and href:
            genres.append({'name': name, 'url': _absolute(href)})

    return genres


def get_genre_content(genre_url: str, page: int = 1) -> tuple[list[dict], bool]:
    """Recupera i contenuti di un genere specifico."""
    provider = _provider()
    if provider:
        return provider.catalog(page, genre=genre_url)
    # Aggiunge la paginazione se necessario
    genre_url = _absolute(genre_url)
    if page > 1:
        genre_url = genre_url.rstrip('/') + f'/page/{page}/'

    soup = _get_soup(genre_url)
    if not soup:
        return [], False

    items = []
    cards = soup.select('article, .film-item, .movie-item, li.item')
    for card in cards:
        item = _parse_card(card)
        if item:
            items.append(item)

    next_page = soup.select_one('a.next, .pagination .next, a[rel="next"]')
    has_next = next_page is not None

    return items, has_next


def get_series_details(series_url: str) -> dict:
    """
    Recupera i dettagli di una serie TV: stagioni e informazioni.
    Restituisce un dict con 'seasons' (lista di numeri) e 'info' (metadati).
    """
    provider = _provider()
    if provider:
        return provider.details(series_url)
    soup = _get_soup(series_url)
    if not soup:
        return {'seasons': [], 'info': {}}

    # ⚠️ Adatta questi selettori alla struttura delle pagine serie del sito
    season_tabs = soup.select('.season-tab, [data-season], button[data-season]')
    seasons = []

    if season_tabs:
        for tab in season_tabs:
            season_num = tab.get('data-season') or tab.get_text(strip=True)
            try:
                seasons.append(int(re.search(r'\d+', str(season_num)).group()))
            except (AttributeError, ValueError):
                pass
    else:
        # Fallback: cerca link/tab con "Stagione N"
        all_text = soup.get_text()
        found = re.findall(r'[Ss]tagione\s+(\d+)', all_text)
        seasons = sorted(set(int(n) for n in found))

    # Metadati della serie
    trama_tag = soup.select_one('.description, .trama, #overview, .plot')
    trama = trama_tag.get_text(strip=True) if trama_tag else ''

    poster_tag = soup.select_one('img.poster, .thumbnail img, .cover img')
    poster = ''
    if poster_tag:
        poster = best_image(poster_tag, series_url)

    return {
        'seasons': sorted(set(seasons)),
        'info': {
            'plot': trama,
            'thumbnail': poster,
        }
    }


def get_episodes(series_url: str, season: int) -> list[dict]:
    """
    Recupera gli episodi di una stagione specifica.
    ⚠️ La struttura varia moltissimo tra i siti; adatta i selettori.
    """
    provider = _provider()
    if provider:
        return provider.episodes(series_url, season)
    soup = _get_soup(series_url)
    if not soup:
        return []

    episodes = []

    # Strategia 1: episodi in tab/div con attributo data-season
    season_container = next((node for node in soup.select(
        f'[data-season="{season}"], #season-{season}, .season-{season}'
    ) if node.select_one('a[href]')), None)
    if season_container:
        ep_links = season_container.select('a[href]')
    elif soup.select_one('[data-season], [id^="season-"]'):
        return []
    else:
        # Strategia 2: tutti i link che contengono "episodio" o "ep"
        ep_links = soup.select('a[href*="episodio"], a[href*="-ep-"], a[href*="/ep/"]')

    for link in ep_links:
        ep_title = link.get_text(strip=True) or f'Episodio'
        ep_url = link.get('href', '')
        if not ep_url:
            continue
        ep_url = _absolute(ep_url, series_url)

        # Prova a estrarre il numero dell'episodio dal testo o URL
        ep_num_match = re.search(r'[Ee]p(?:isodio)?\s*(\d+)', ep_title + ep_url)
        ep_num = int(ep_num_match.group(1)) if ep_num_match else len(episodes) + 1

        episodes.append({
            'title': ep_title if ep_title else f'Episodio {ep_num}',
            'url': ep_url,
            'episode': ep_num,
            'season': season,
            'thumbnail': '',
        })

    # Ordina per numero episodio
    episodes.sort(key=lambda x: x['episode'])
    return episodes


def playback_sources(url):
    provider = _provider()
    return provider.streams(url) if isinstance(provider, cb01.Provider) else None


def _playback_headers(stream, referer):
    if not stream or '|' in stream:
        return stream
    headers = {'Referer': referer, 'User-Agent': SESSION.headers['User-Agent']}
    prepared = SESSION.prepare_request(requests.Request('GET', stream))
    if prepared.headers.get('Cookie'):
        headers['Cookie'] = prepared.headers['Cookie']
    return stream + '|' + '&'.join(requests.utils.quote(key, safe='') + '=' +
                                  requests.utils.quote(value, safe='') for key, value in headers.items())


def resolve_stream(page_url: str, _visited=None, _depth=0) -> str | None:
    """Estrae media diretti e segue iframe HTML, con limite e controllo cicli."""
    page_url = _absolute(page_url)
    if not page_url:
        return None
    if urlparse(page_url).path.lower().endswith(('.mp4', '.m3u8', '.webm', '.mpd')):
        return _playback_headers(page_url, BASE_URL + '/')
    visited = set() if _visited is None else _visited
    if page_url in visited or _depth > 3:
        return None
    visited.add(page_url)
    try:
        import resolveurl
        hosted = resolveurl.HostedMediaFile(url=page_url)
        if hosted.valid_url():
            resolved = hosted.resolve()
            if resolved:
                return _playback_headers(resolved, page_url)
    except ImportError:
        pass
    except Exception as exc:
        xbmc.log('[StreamIt] Resolver failed: ' + type(exc).__name__ + '; trying HTML player.', xbmc.LOGWARNING)
    soup = _get_soup(page_url)
    if soup is None:
        return None
    base = getattr(soup, '_streamit_url', None) or page_url
    player_embed = sc.embed(soup)
    if player_embed:
        return resolve_stream(_absolute(player_embed, base), visited, _depth + 1)
    stream = sc.playlist(soup)
    if stream:
        return _playback_headers(stream, base)
    for source in soup.select('video[src], video source[src]'):
        stream = _absolute(source.get('src', ''), base)
        if stream:
            return _playback_headers(stream, base)
    for frame in soup.select('iframe[src], iframe[data-src]'):
        frame_url = _absolute(frame.get('data-src') or frame.get('src', ''), base)
        if 'youtube.com' in urlparse(frame_url).netloc:
            continue
        try:
            stream = resolve_stream(frame_url, visited, _depth + 1)
        except RuntimeError:
            continue
        if stream:
            return stream
    return None
