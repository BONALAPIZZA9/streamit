# -*- coding: utf-8 -*-
"""
Modulo di navigazione: costruisce i menu di Kodi e gestisce la riproduzione.
"""
from urllib.parse import urlencode
import os
import json
import xbmcvfs

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib import scraper
from resources.lib.sources import get_sources
from resources.lib.catalog_cache import CatalogCache
from resources.lib.category_art import choose_icon


class Navigator:
    """Gestisce la navigazione nell'addon e la costruzione dei menu Kodi."""

    def __init__(self, handle: int, base_url: str, addon, source=None):
        self.handle = handle
        self.base_url = base_url
        self.addon = addon
        self.sources = get_sources(addon)
        self.source = source if source in [s['url'] for s in self.sources] else self.sources[0]['url']
        scraper.configure(addon, self.source)


    # ─── Helpers ──────────────────────────────────────────────────────────────

    @property
    def cache(self):
        return CatalogCache(os.path.join(xbmcvfs.translatePath(self.addon.getAddonInfo('profile')), 'catalog'), self.source)

    def _build_url(self, **params) -> str:
        """Costruisce un URL plugin:// con i parametri dati."""
        params.setdefault('source', self.source)
        return f'{self.base_url}?{urlencode(params)}'

    def _add_directory_item(self, title: str, url: str,
                             thumbnail: str = '', info: dict = None,
                             is_folder: bool = True, artwork=None):
        """Aggiunge un elemento navigabile alla lista corrente."""
        list_item = xbmcgui.ListItem(label=title, path=url)

        icon = os.path.join(self.addon.getAddonInfo('path'), 'resources', 'media', 'categories', choose_icon(title, url) + '.png')
        art = {'thumb': thumbnail or icon, 'icon': thumbnail or icon, 'poster': thumbnail or icon}
        if artwork:
            art.update({key: value for key, value in artwork.items() if value})
        list_item.setArt(art)

        meta = {'title': title}
        if info:
            meta.update(info)
        list_item.setInfo('video', meta)

        if not is_folder:
            list_item.setProperty('IsPlayable', 'true')
            list_item.setProperty('ForceResolvePlugin', 'true')

        xbmcplugin.addDirectoryItem(
            handle=self.handle,
            url=url,
            listitem=list_item,
            isFolder=is_folder
        )

    def _end_directory(self, cache: bool = False):
        """Finalizza e mostra la directory corrente."""
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=cache)

    def _add_next_page(self, action: str, current_page: int, **extra_params):
        """Aggiunge il pulsante 'Pagina successiva' alla lista."""
        next_page = current_page + 1
        url = self._build_url(action=action, page=next_page, **extra_params)
        self._add_directory_item(
            title='Pagina successiva →',
            url=url,
            is_folder=True
        )

    # ─── Schermate principali ─────────────────────────────────────────────────

    def show_home(self):
        """Mostra il menu principale."""
        items = [(label, self._build_url(action=action)) for label, action in [
            ('Film', 'movies'), ('Serie', 'series'), ('Cerca', 'search'),
            ('IPTV', 'iptv'), ('Generi', 'genres'), ('Gestione', 'manage')]]
        for title, url in items:
            self._add_directory_item(title=title, url=url)

        xbmcplugin.setPluginCategory(self.handle, 'StreamIt')
        self._end_directory()

    def show_iptv(self, playlist='italia', page=1):
        from resources.lib.iptv import load_channels, channel_key, channel_info
        from resources.lib.iptv_access import authorize
        if playlist == 'italia' and xbmc.getCondVisibility('System.HasAddon(plugin.video.wltvhelper)'):
            self._add_directory_item('World Live TV', 'plugin://plugin.video.wltvhelper/')
            if self.addon.getSetting('iptv_password_hash'):
                self._add_directory_item('IPTV alternativa', self._build_url(action='iptv', playlist='alternative'))
            xbmcplugin.setPluginCategory(self.handle, 'IPTV')
            self._end_directory(cache=False)
            return
        if playlist == 'alternative' and not authorize(force=page == 1):
            self._end_directory(cache=False)
            return
        if playlist == 'italia' and self.addon.getSetting('iptv_password_hash'):
            self._add_directory_item('IPTV alternativa', self._build_url(action='iptv', playlist='alternative'))
        channels = load_channels(playlist)
        actual = channels[0]['playlist']
        if actual == 'alternative' and playlist != actual and not authorize(force=True):
            self._end_directory(cache=False)
            return
        if actual != playlist:
            xbmcgui.Dialog().notification('StreamIt', 'Playlist italiana non disponibile: aperta IPTV alternativa.', time=5000)
        helper_ready = xbmc.getCondVisibility('System.HasAddon(plugin.video.wltvhelper)')
        if actual == 'italia' and not helper_ready and page == 1:
            xbmcgui.Dialog().notification('StreamIt', 'Per i canali World Live TV installa e abilita World Live TV Helper.', time=6000)
        start = (page - 1) * 100
        for channel in channels[start:start + 100]:
            target = (channel['url'] if channel['url'].startswith('plugin://plugin.video.wltvhelper/') and helper_ready
                      else self._build_url(action='play_iptv', channel=channel['name'], playlist=actual, key=channel_key(channel)))
            self._add_directory_item(channel['name'], target,
                thumbnail=channel['logo'], info=channel_info(channel), is_folder=False)
        if start + 100 < len(channels):
            self._add_next_page('iptv', page, playlist=actual)
        xbmcplugin.setPluginCategory(self.handle, 'IPTV · World Live TV' if actual == 'italia' else 'IPTV alternativa')
        self._end_directory(cache=False)

    def play_iptv(self, name, playlist='italia', key=''):
        from resources.lib.iptv import load_channels, playback_url, channel_key, channel_info
        if playlist == 'alternative':
            from resources.lib.iptv_access import authorize
            if not authorize():
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                return
        channel = next((c for c in load_channels(playlist, fallback=False)
                        if (channel_key(c) == key if key else c['name'] == name)), None)
        if channel is None:
            raise RuntimeError('Canale non trovato. Riapri la sezione IPTV.')
        url = playback_url(channel)
        if url.startswith('plugin://plugin.video.wltvhelper/') and not xbmc.getCondVisibility('System.HasAddon(plugin.video.wltvhelper)'):
            raise RuntimeError('Installa e abilita World Live TV Helper dal repository ufficiale: https://worldlivetv.github.io/repo/ . Poi riapri IPTV. Puoi anche usare IPTV alternativa.')
        item = xbmcgui.ListItem(label=channel['name'], path=url)
        item.setInfo('video', channel_info(channel))
        item.setArt({'thumb': channel['logo']})
        item.setContentLookup(False)
        path = url.split('|')[0].split('?')[0].lower()
        if path.endswith('.mpd'):
            if not xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
                raise RuntimeError('Questo canale richiede InputStream Adaptive. Installalo dagli add-on di Kodi.')
            item.setProperty('inputstream', 'inputstream.adaptive')
            headers = url.partition('|')[2]
            if headers:
                item.setProperty('inputstream.adaptive.manifest_headers', headers)
                item.setProperty('inputstream.adaptive.stream_headers', headers)
            item.setMimeType('application/dash+xml')
        elif path.endswith('.m3u8'):
            item.setMimeType('application/vnd.apple.mpegurl')
        xbmcplugin.setResolvedUrl(self.handle, True, item)

    def show_manage(self):
        for label, action in [('Aggiorna catalogo', 'refresh_all'), ('Impostazioni', 'settings')]:
            self._add_directory_item(label, self._build_url(action=action))
        self._end_directory()

    def show_settings(self):
        self.addon.openSettings()
        self.sources = get_sources(self.addon)
        self.source = self.sources[0]['url']
        scraper.configure(self.addon, self.source)
        self.show_home()



    def _catalog(self, name, *args):
        cached = self.cache.get(name, *args)
        return cached if cached is not None else getattr(scraper, name)(*args)

    def refresh_all(self):
        dialog = xbmcgui.DialogProgress()
        dialog.create('Aggiorna tutte le categorie', 'Aggiornamento della fonte selezionata...')
        values, failures = {}, []
        cancelled = False
        tasks = [('Film', 'get_movies', (1,)), ('Serie TV', 'get_series', (1,)),
                 ('Generi', 'get_genres', ())]
        self.cache.clear()
        try:
            index = 0
            while index < len(tasks):
                if dialog.iscanceled():
                    cancelled = True
                    break
                label, name, args = tasks[index]
                dialog.update(int(index * 100 / len(tasks)), label)
                try:
                    result = getattr(scraper, name)(*args)
                    values[CatalogCache.key(name, args)] = result
                    if name == 'get_genres':
                        tasks.extend((g['name'], 'get_genre_content', (g['url'], 1)) for g in result)
                except (RuntimeError, ValueError) as exc:
                    failures.append(label + ': ' + str(exc))
                index += 1
            self.cache.save(values)
        finally:
            dialog.close()
        if failures:
            xbmcgui.Dialog().ok('Aggiornamento parziale', '\n'.join(failures))
        else:
            message = 'Aggiornamento interrotto' if cancelled else 'Tutte le categorie aggiornate'
            xbmcgui.Dialog().notification('StreamIt', message, xbmcgui.NOTIFICATION_INFO, 3000)
        self.show_home()

    def show_search(self, kind=None):
        if kind not in ('movie', 'tv'):
            self._add_directory_item('Cerca film', self._build_url(action='search', kind='movie'))
            self._add_directory_item('Cerca serie', self._build_url(action='search', kind='tv'))
            self._end_directory(cache=False)
            return
        keyboard = xbmc.Keyboard('', 'Cerca serie' if kind == 'tv' else 'Cerca film')
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText().strip()
            if query:
                self.show_search_results(query, kind)
                return
        self._end_directory(cache=False)

    def show_search_results(self, query: str, kind='movie', page=1):
        """Mostra i risultati di ricerca."""
        kind = 'tv' if kind == 'tv' else 'movie'
        xbmcplugin.setPluginCategory(self.handle, ('Serie: ' if kind == 'tv' else 'Film: ') + query)
        xbmcplugin.setContent(self.handle, 'tvshows' if kind == 'tv' else 'movies')
        scraper.configure(self.addon, 'https://vixsrc.to')
        results, has_next = scraper.search(query, kind, page)

        if not results and not has_next:
            xbmcgui.Dialog().notification(
                'StreamIt', 'Nessun risultato trovato.',
                xbmcgui.NOTIFICATION_INFO, 3000
            )
            self._end_directory(cache=False)
            return

        for item in results:
            self._add_content_item(item)

        if has_next:
            self._add_next_page('search_results', page, query=query, kind=kind)
        self._end_directory(cache=False)

    def show_movies(self, page: int = 1):
        """Mostra la lista dei film con paginazione."""
        xbmcplugin.setPluginCategory(self.handle, f'Film - Pagina {page}')
        xbmcplugin.setContent(self.handle, 'movies')

        movies, has_next = self._unified_movies(page)
        if page > 1:
            self._add_directory_item('← Pagina precedente', self._build_url(action='movies', page=page - 1))
        if has_next:
            self._add_next_page('movies', page)
        for movie in movies:
            self._add_content_item(movie)

        if has_next:
            self._add_next_page('movies', page)

        self._end_directory()

    def _unified_movies(self, page=1, query=None):
        scraper.configure(self.addon, 'https://vixsrc.to')
        if query is not None:
            return scraper.search(query), False
        return scraper.get_movies(page)

    def show_series(self, page: int = 1):
        """Mostra la lista delle serie TV con paginazione."""
        xbmcplugin.setPluginCategory(self.handle, f'Serie TV - Pagina {page}')
        xbmcplugin.setContent(self.handle, 'tvshows')

        scraper.configure(self.addon, 'https://vixsrc.to')
        series_list, has_next = scraper.get_series(page)
        for series in series_list:
            self._add_content_item(series)

        if has_next:
            self._add_next_page('series', page)

        self._end_directory()

    def show_genres(self, kind=None):
        """Mostra la lista dei generi."""
        xbmcplugin.setPluginCategory(self.handle, 'Generi')
        if kind not in ('movie', 'tv'):
            self._add_directory_item('Generi film', self._build_url(action='genres', kind='movie'))
            self._add_directory_item('Generi serie', self._build_url(action='genres', kind='tv'))
            self._end_directory(cache=False)
            return
        scraper.configure(self.addon, 'https://vixsrc.to')
        genres = scraper.get_genres(kind)

        if not genres:
            xbmcgui.Dialog().notification(
                'StreamIt', 'Impossibile caricare i generi.',
                xbmcgui.NOTIFICATION_ERROR, 3000
            )
            self._end_directory(cache=False)
            return

        for genre in genres:
            url = self._build_url(
                action='genre_content',
                genre=genre['url'],
                content_type=kind
            )
            self._add_directory_item(title=genre['name'], url=url)

        self._end_directory()

    def show_genre_content(self, genre: str, content_type: str = 'auto', page: int = 1):
        """Mostra i contenuti di un genere."""
        xbmcplugin.setPluginCategory(self.handle, f'Genere - Pagina {page}')
        kind = 'tv' if content_type == 'tv' else 'movie'
        scraper.configure(self.addon, 'https://vixsrc.to')
        xbmcplugin.setContent(self.handle, 'tvshows' if kind == 'tv' else 'movies')
        items, has_next = scraper.get_genre_content(genre, page, kind)

        for item in items:
            self._add_content_item(item)

        if has_next:
            self._add_next_page('genre_content', page, genre=genre, content_type=content_type)

        self._end_directory()

    # ─── Serie TV ─────────────────────────────────────────────────────────────

    def show_seasons(self, series_url: str, series_title: str):
        """Mostra le stagioni di una serie TV."""
        xbmcplugin.setPluginCategory(self.handle, series_title)
        details = scraper.get_series_details(series_url)

        if not details['seasons']:
            xbmcgui.Dialog().notification(
                'StreamIt', 'Nessuna stagione trovata.',
                xbmcgui.NOTIFICATION_WARNING, 3000
            )
            self._end_directory(cache=False)
            return

        for season_num in details['seasons']:
            url = self._build_url(
                action='episodes',
                url=series_url,
                season=season_num,
                title=series_title
            )
            self._add_directory_item(
                title=f'Stagione {season_num}',
                url=url,
                thumbnail=details['info'].get('thumbnail', '')
            )

        self._end_directory()

    def show_episodes(self, series_url: str, season: int, series_title: str):
        """Mostra gli episodi di una stagione."""
        xbmcplugin.setPluginCategory(self.handle, f'{series_title} - Stagione {season}')
        xbmcplugin.setContent(self.handle, 'episodes')

        episodes = scraper.get_episodes(series_url, season)

        if not episodes:
            xbmcgui.Dialog().notification(
                'StreamIt', 'Nessun episodio trovato.',
                xbmcgui.NOTIFICATION_WARNING, 3000
            )
            self._end_directory(cache=False)
            return

        for ep in episodes:
            url = self._build_url(
                action='play',
                url=ep['url'],
                title=ep['title'],
                thumbnail=ep.get('thumbnail', ''),
                direct='true' if self.source == 'https://vixsrc.to' else 'false'
            )
            info = {
                'mediatype': 'episode',
                'episode': ep.get('episode', 0),
                'season': ep.get('season', season),
                'tvshowtitle': series_title,
            }
            self._add_directory_item(
                title=ep['title'],
                url=url,
                thumbnail=ep.get('thumbnail', ''),
                info=info,
                artwork=ep.get('art', {}),
                is_folder=False
            )

        self._end_directory()

    # ─── Riproduzione ─────────────────────────────────────────────────────────

    def open_external(self, url):
        from urllib.parse import urlparse
        if urlparse(url).scheme not in ('http', 'https'):
            raise ValueError('Indirizzo del lettore non valido.')
        if xbmc.getCondVisibility('System.Platform.Android'):
            xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","","' + url.replace('"', '%22') + '")')
        else:
            import webbrowser
            if not webbrowser.open(url):
                xbmcgui.Dialog().ok('Lettore esterno', 'Nessun browser disponibile. Apri questo indirizzo nel browser:\n' + url)

    def play_content(self, url: str, title: str, thumbnail: str = '', candidates='', direct=False):
        """Risolve lo stream e lo avvia in Kodi."""
        xbmc.log('[StreamIt] Film resolver started.', xbmc.LOGINFO)
        # Mostra finestra di caricamento
        sources = None if direct else scraper.playback_sources(url)
        if sources is not None:
            if not sources:
                raise RuntimeError('Nessun collegamento video disponibile per questo contenuto.')
            choice = xbmcgui.Dialog().select('Scegli lettore', [s['name'] for s in sources])
            if choice < 0:
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                return
            url = sources[choice]['url']
        dialog = xbmcgui.DialogProgress()
        dialog.create('StreamIt', f'Caricamento: {title}...')
        dialog.update(30, 'Recupero link stream...')

        try:
            stream_url = scraper.resolve_stream(url)
            if stream_url:
                scraper.validate_stream(stream_url)
            if dialog.iscanceled():
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                return
            dialog.update(90, 'Avvio riproduzione...')
        finally:
            dialog.close()

        if not stream_url:
            xbmcgui.Dialog().ok(
                'StreamIt - Errore',
                'Impossibile trovare lo stream per questo contenuto.\n'
                'Il lettore esterno potrebbe essere bloccato o non supportato.\n'
                'Controlla il log per dettagli.'
            )
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        play_item = xbmcgui.ListItem(label=title, path=stream_url)
        play_item.setArt({'thumb': thumbnail})
        play_item.setInfo('video', {'title': title})

        # Imposta mimetype per HLS se è un .m3u8
        if '.m3u8' in stream_url or '/playlist/' in stream_url:
            play_item.setMimeType('application/x-mpegURL')
            play_item.setContentLookup(False)

        from resources.lib.audio import prepare
        prepare(stream_url, title)
        xbmc.log('[StreamIt] Film resolved; handing media to Kodi.', xbmc.LOGINFO)
        xbmcplugin.setResolvedUrl(self.handle, True, play_item)

    # ─── Helper privato ───────────────────────────────────────────────────────

    def _add_content_item(self, item: dict):
        """Aggiunge un film o una serie alla lista, gestendo la navigazione."""
        title = item.get('title', 'Titolo sconosciuto')
        thumbnail = item.get('thumbnail', '')
        content_url = item.get('url', '')
        year = item.get('year', '')
        content_type = item.get('type', 'movie')

        info = {'title': title, 'mediatype': 'tvshow' if content_type == 'series' else 'movie'}
        if year:
            try:
                info['year'] = int(str(year)[:4])
            except (ValueError, TypeError):
                pass

        if content_type == 'series':
            # Serie TV → mostra le stagioni
            nav_url = self._build_url(
                action='seasons',
                url=content_url,
                title=title, source=item.get('source', self.source)
            )
            self._add_directory_item(
                title=f'[B]{title}[/B]' + (f' ({year})' if year else ''),
                url=nav_url,
                thumbnail=thumbnail,
                info=info,
                artwork=item.get('art', {}),
                is_folder=True
            )
        else:
            # Film → riproduci direttamente
            nav_url = self._build_url(
                action='play',
                url=content_url,
                title=title,
                thumbnail=thumbnail,
                source=item.get('source', self.source),
                direct='true'
            )
            self._add_directory_item(
                title=f'[B]{title}[/B]' + (f' ({year})' if year else ''),
                url=nav_url,
                thumbnail=thumbnail,
                info=info,
                artwork=item.get('art', {}),
                is_folder=False
            )
