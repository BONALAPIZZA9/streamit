"""Riconoscimento strutturale; nessuna compatibilità dedotta dal nome del dominio."""
import json
from resources.lib import cb01
from urllib.parse import urljoin, urlparse


def detect(soup):
    if cb01.supports(soup):
        return 'cb01'
    node = soup.select_one('[data-page]')
    if node:
        try:
            page = json.loads(node['data-page'])
            props = page.get('props', {})
            if (page.get('component', '').startswith(('Home/', 'Titles/'))
                    and props.get('scws_url') and props.get('cdn_url')
                    and any(key in props for key in ('sliders', 'titles', 'title'))):
                return 'streamingcommunity'
        except (ValueError, TypeError, AttributeError):
            pass
    if soup.select_one('video[src], video source[src]'):
        return 'html_video'
    for link in soup.select('a[href]'):
        if urlparse(link['href']).path.lower().endswith(('.mp4', '.m3u8', '.webm', '.mpd')):
            return 'html_video'
    return 'unknown'


class MediaProvider:
    """Elenca soltanto i media esplicitamente pubblicati in una pagina HTML."""
    def __init__(self, base, soup):
        self.base, self.soup = base, soup

    def catalog(self, page=1, kind=None, query=None, genre=None):
        if page != 1 or kind == 'tv' or genre:
            return [], False
        items, seen = [], set()
        page_title = self.soup.title.get_text(strip=True) if self.soup.title else 'Video'
        for node in self.soup.select('video[src], video source[src], a[href]'):
            raw = node.get('src') or node.get('href')
            if node.name == 'a' and not urlparse(raw).path.lower().endswith(('.mp4', '.m3u8', '.webm', '.mpd')):
                continue
            url = urljoin(self.base, raw)
            if urlparse(url).scheme not in ('http', 'https') or url in seen:
                continue
            seen.add(url)
            video = node if node.name == 'video' else node.find_parent('video')
            title = node.get('title') or node.get_text(strip=True) or page_title
            poster = video.get('poster', '') if video else ''
            if not query or query.casefold() in title.casefold():
                items.append({'title': title, 'url': url, 'type': 'movie',
                              'thumbnail': urljoin(self.base, poster) if poster else '', 'year': ''})
        return items, False

    def genres(self):
        return []

    def details(self, url):
        return {'seasons': [], 'info': {}}

    def episodes(self, url, season):
        return []
