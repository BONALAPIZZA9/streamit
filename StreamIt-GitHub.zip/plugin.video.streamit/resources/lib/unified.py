"""Merge movie catalogues while retaining each playback source."""
import re
import unicodedata


def clean_title(title):
    title = re.sub(r'\[[^]]*\]|\((?:19|20)\d{2}\)', '', title)
    return re.sub(r'\s+', ' ', title).strip()


def merge_catalogues(batches):
    result, indexed = [], {}
    for source, items in batches:
        for item in items:
            if item.get('type') == 'series':
                continue
            title = clean_title(item['title'])
            normalized = unicodedata.normalize('NFKD', title).casefold()
            normalized = ''.join(c for c in normalized if c.isalnum())
            key = (normalized, str(item.get('year', '')))
            candidate = {'url': item['url'], 'source': source, 'name': source.split('://')[-1]}
            if key in indexed:
                entry = indexed[key]
                if candidate not in entry['candidates']:
                    entry['candidates'].append(candidate)
            else:
                entry = dict(item, title=title, source=source, candidates=[candidate])
                indexed[key] = entry
                result.append(entry)
    return result
