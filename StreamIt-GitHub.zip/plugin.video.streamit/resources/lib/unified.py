"""Merge movie catalogues while retaining each playback source."""
import re
import unicodedata
from urllib.parse import urlparse
import requests
from bs4 import BeautifulSoup


def clean_title(title):
    title = re.sub(r'\[[^]]*\]|\((?:19|20)\d{2}\)', '', title)
    return re.sub(r'\s+', ' ', title).strip()


def normalized_title(title):
    title = unicodedata.normalize('NFKD', clean_title(title)).casefold()
    return ''.join(c for c in title if c.isalnum())


def identify_movie(item):
    """Match both localized and original titles, with release year required."""
    year = str(item.get('year', ''))
    if not year:
        return item
    try:
        response = requests.get('https://www.themoviedb.org/search/movie', params={'query': clean_title(item['title']), 'language': 'it-IT'}, timeout=12)
        response.raise_for_status()
    except requests.RequestException:
        return item
    soup = BeautifulSoup(response.text, 'html.parser')
    matches = set()
    for link in soup.select('a[data-media-type="movie"][href]'):
        heading = link.find('h2')
        match = re.match(r'/movie/(\d+)', urlparse(link['href']).path)
        if not heading or not match:
            continue
        release = link.parent.select_one('.release_date')
        if not release or not re.search(r'\b' + re.escape(year) + r'\b', release.get_text()):
            continue
        names = [span.get_text(strip=True).strip(' ()') for span in heading.find_all('span')] or [heading.get_text(strip=True)]
        if any(normalized_title(name) == normalized_title(item['title']) for name in names):
            matches.add(int(match.group(1)))
    if not matches and ':' in clean_title(item['title']):
        original = clean_title(item['title']).split(':', 1)[0].strip()
        if len(normalized_title(original)) >= 8:
            identified = identify_movie(dict(item, title=original))
            if identified.get('tmdb_id'):
                return dict(item, tmdb_id=identified['tmdb_id'])
    return dict(item, tmdb_id=matches.pop()) if len(matches) == 1 else item


def merge_catalogues(batches, vix_ids=()):
    vix = [item for source, items in batches if source == "https://vixsrc.to" for item in items]
    cb01 = [item for source, items in batches if source != "https://vixsrc.to" for item in items]
    result, identifiers, titles = [], set(vix_ids), {}
    for item in vix:
        identifier = item.get('tmdb_id')
        if identifier and any(entry.get('tmdb_id') == identifier for entry in result):
            continue
        result.append(dict(item, source='https://vixsrc.to'))
        if identifier:
            identifiers.add(identifier)
        titles.setdefault(normalized_title(item['title']), []).append(item)
    seen = set()
    for item in cb01:
        if item.get('type') == 'series':
            continue
        identifier = item.get('tmdb_id')
        name, year = normalized_title(item['title']), str(item.get('year', ''))
        key = ('id', identifier) if identifier else (name, year)
        if (identifier and identifier in identifiers) or key in seen:
            continue
        possible = titles.get(name, [])
        if not identifier and len(possible) == 1 and year and str(possible[0].get('year', '')) == year:
            continue
        seen.add(key)
        result.append(dict(item, title=clean_title(item['title']), source='https://cb01uno.vip'))
    return result

