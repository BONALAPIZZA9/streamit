"""Use Kodi's repository updater, leaving package installation to Kodi."""
import time
import xbmc
import xbmcaddon


class RepositoryUpdates:
    def __init__(self):
        self.next_check = time.monotonic() + 30

    def tick(self, playing=False):
        now = time.monotonic()
        if now < self.next_check or playing:
            return
        addon = xbmcaddon.Addon('plugin.video.streamit')
        if addon.getSetting('auto_repository_updates') == 'false':
            self.next_check = now + 60
            return
        xbmc.executebuiltin('UpdateAddonRepos()')
        self.next_check = now + 6 * 60 * 60
