"""Select real high-resolution images without inventing remote URLs."""
from urllib.parse import urljoin, urlparse


def best_image(image, base):
    if image is None:
        return ''
    def usable(value):
        url = urljoin(base, (value or '').strip())
        return url if urlparse(url).scheme in ('http', 'https') else ''
    for key in ('data-original', 'data-full', 'data-large', 'data-lazy-src'):
        value = usable(image.get(key))
        if image.get(key) and value:
            return value
    candidates = []
    nodes = [image]
    if image.parent and image.parent.name == 'picture':
        nodes += image.parent.select('source')
    for node in nodes:
        for entry in (node.get('data-srcset') or node.get('srcset') or '').split(','):
            parts = entry.strip().rsplit(None, 1)
            if len(parts) != 2 or parts[1][-1:] not in ('w', 'x'):
                continue
            try:
                size = float(parts[1][:-1])
            except ValueError:
                continue
            value = usable(parts[0])
            if value:
                candidates.append((size, value))
    if candidates:
        return max(candidates, key=lambda item: item[0])[1]
    for key in ('data-src', 'src'):
        value = usable(image.get(key))
        if image.get(key) and value:
            return value
    return ''
