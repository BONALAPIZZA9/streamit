"""Registro delle fonti configurate dall'utente."""
from urllib.parse import urlparse

DEFAULT_SITE = 'https://streamingcommunityz.rip'
EXAMPLE_SITE = 'https://streamingcommunityz.rip'


def get_sources(addon):
    primary = addon.getSetting('base_url') or DEFAULT_SITE
    additional = addon.getSetting('additional_sites')
    result = []
    for raw in [primary] + additional.replace('\n', ';').split(';'):
        url = raw.strip().rstrip('/')
        if not url:
            continue
        if '://' not in url:
            url = 'https://' + url
        parsed = urlparse(url)
        if parsed.scheme not in ('http', 'https') or not parsed.netloc or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError('Indirizzo sito non valido: usa un URL HTTP o HTTPS senza query o credenziali.')
        if url not in [item['url'] for item in result]:
            result.append({'name': parsed.netloc, 'url': url})
    return result


def save_source(addon, value, previous=None):
    """Normalizza e salva una fonte, preservando le altre."""
    value = value.strip().rstrip('/')
    if '://' not in value:
        value = 'https://' + value
    parsed = urlparse(value)
    try:
        port = parsed.port
    except ValueError:
        raise ValueError('La porta del sito non è valida.')
    if (parsed.scheme not in ('http', 'https') or not parsed.hostname
            or any(c.isspace() for c in value) or parsed.username or parsed.password
            or parsed.query or parsed.fragment or ';' in value):
        raise ValueError('Inserisci un indirizzo HTTP o HTTPS senza credenziali, spazi o query.')
    value = parsed._replace(netloc=parsed.netloc.lower()).geturl()
    urls = [item['url'] for item in get_sources(addon)]
    if value in urls and value != previous:
        raise ValueError('Questo sito è già presente.')
    if previous is not None:
        if previous not in urls:
            raise ValueError('Il sito da modificare non è più presente.')
        urls[urls.index(previous)] = value
    else:
        urls.append(value)
    addon.setSetting('base_url', urls[0])
    addon.setSetting('additional_sites', ';'.join(urls[1:]))
    return value
