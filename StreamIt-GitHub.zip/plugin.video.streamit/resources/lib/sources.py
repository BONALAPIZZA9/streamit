"""Fixed sources; site editing is intentionally unavailable."""
DEFAULT_SITE = 'https://vixsrc.to'
def get_sources(addon=None):
    return [{'name': 'VixSrc', 'url': DEFAULT_SITE}, {'name': 'CB01', 'url': 'https://cb01uno.wiki'}]
