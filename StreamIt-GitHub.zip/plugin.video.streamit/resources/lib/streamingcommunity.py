"""Adattatore per il catalogo Inertia di StreamingCommunity."""
import json
import re
from urllib.parse import urlencode, urlparse, parse_qsl, urlunparse


def supports(base):
    host = urlparse(base).hostname or ''
    return host.startswith('streamingcommunity')


def props(soup):
    node = soup.select_one('[data-page]')
    if not node:
        raise RuntimeError('Il sito non ha restituito il catalogo atteso. Potrebbe richiedere accesso o aver cambiato struttura.')
    try:
        return json.loads(node['data-page'])['props']
    except (ValueError, KeyError, TypeError) as exc:
        raise RuntimeError('Dati del catalogo non validi.') from exc


class Provider:
    def __init__(self, base, get_soup):
        self.base = base.rstrip('/')
        self.get_soup = get_soup

    def artwork(self, title, data):
        images = title.get('images') or []
        def pick(kind):
            candidates = [im for im in images if im.get('type') == kind and im.get('filename')]
            def quality(im):
                try:
                    width = int(im.get('width') or 0)
                    height = int(im.get('height') or 0)
                except (TypeError, ValueError):
                    width = height = 0
                return (width * height if height else width, im.get('lang') == 'it')
            candidates.sort(key=quality, reverse=True)
            if not candidates:
                return ''
            return data.get('cdn_url', '').rstrip('/') + '/images/' + candidates[0]['filename']
        poster = pick('poster')
        landscape = pick('cover') or pick('background')
        return {'poster': poster, 'thumb': landscape or poster,
                'fanart': pick('background') or landscape, 'landscape': landscape,
                'clearlogo': pick('logo'), 'icon': poster}

    def image(self, title, data):
        return self.artwork(title, data)['poster']

    def item(self, title, data):
        series = title.get('type') == 'tv'
        title_id = int(title['id'])
        url = (self.base + '/it/titles/' + str(title_id) + '-' + title['slug'] if series
               else self.base + '/it/watch/' + str(title_id))
        return {'title': title['name'], 'url': url, 'type': 'series' if series else 'movie',
                'thumbnail': self.image(title, data), 'art': self.artwork(title, data), 'year': str(title.get('release_date') or '')[:4]}

    def catalog(self, page=1, kind=None, query=None, genre=None):
        params = {'page': max(1, int(page))}
        if kind: params['type'] = kind
        if query: params['search'] = query
        if genre: params['genre[]'] = genre
        data = props(self.get_soup(self.base + '/it/archive', params=params))
        titles = data.get('titles')
        if not isinstance(titles, list):
            raise RuntimeError('Formato del catalogo cambiato: lista titoli assente.')
        items = [self.item(t, data) for t in titles]
        return items, bool(titles) and page * 60 < int(data.get('totalCount', 0))

    def genres(self):
        data = props(self.get_soup(self.base + '/it/archive'))
        return [{'name': g['name'], 'url': str(g['id'])} for g in data.get('genres', [])]

    def details(self, url):
        data = props(self.get_soup(url))
        title = data.get('title', {})
        return {'seasons': sorted({int(s['number']) for s in title.get('seasons', [])}),
                'info': {'plot': title.get('plot', ''), 'thumbnail': self.image(title, data), 'art': self.artwork(title, data)}}

    def episodes(self, url, season):
        url = re.sub(r'/season-\d+/?$', '', url.rstrip('/')) + '/season-' + str(int(season))
        data = props(self.get_soup(url))
        loaded = data.get('loadedSeason') or {}
        if int(loaded.get('number', -1)) != int(season):
            raise RuntimeError('Il sito ha restituito una stagione diversa da quella richiesta.')
        title = data['title']
        return [{'title': 'Episodio %s — %s' % (ep['number'], ep.get('name') or ''),
                 'url': self.base + '/it/watch/' + str(title['id']) + '?' + urlencode({'e': ep['id']}),
                 'episode': int(ep['number']), 'season': int(season),
                 'thumbnail': self.image(title, data), 'art': self.artwork(title, data)}
                for ep in loaded.get('episodes', []) if ep.get('scws_id')]


def embed(soup):
    node = soup.select_one('[data-page]')
    if not node:
        return None
    data = props(soup)
    if data.get('redirectToLogin'):
        raise RuntimeError('Questo contenuto richiede accesso sul sito; autenticazione non supportata.')
    return data.get('embedUrl')


def playlist(soup):
    """Legge i parametri pubblicati dal player senza eseguire JavaScript."""
    for script in soup.select('script:not([src])'):
        text = script.get_text()
        match = re.search(r'window\.masterPlaylist\s*=\s*(.*?)(?:window\.|$)', text, re.S)
        if not match:
            continue
        block = match.group(1)
        values = dict(re.findall(r"['\"]?(url|token|expires|asn)['\"]?\s*:\s*['\"]([^'\"]*)['\"]", block))
        url = values.pop('url', '').replace('\\/', '/')
        if not url:
            continue
        parsed = urlparse(url)
        if parsed.scheme not in ('http', 'https'):
            continue
        params = dict(parse_qsl(parsed.query))
        params.update({k: v for k, v in values.items() if v})
        return urlunparse(parsed._replace(query=urlencode(params)))
    return None
