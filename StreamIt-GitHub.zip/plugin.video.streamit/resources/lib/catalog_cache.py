"""Cache per fonte delle prime pagine; aggiornamento manuale e scadenza breve."""
import hashlib
import json
import os
import time


class CatalogCache:
    def __init__(self, folder, source):
        self.folder = folder
        self.path = os.path.join(folder, hashlib.sha256(source.encode('utf-8')).hexdigest() + '.json')

    @staticmethod
    def key(name, args):
        return json.dumps([name, list(args)], sort_keys=True)

    def read(self):
        try:
            with open(self.path, encoding='utf-8') as stream:
                data = json.load(stream)
            if time.time() - data['created'] < 600:
                return data['values']
        except (OSError, ValueError, KeyError, TypeError):
            pass
        return {}

    def get(self, name, *args):
        return self.read().get(self.key(name, args))

    def save(self, values):
        os.makedirs(self.folder, exist_ok=True)
        temp = self.path + '.tmp'
        with open(temp, 'w', encoding='utf-8') as stream:
            json.dump({'created': time.time(), 'values': values}, stream, ensure_ascii=False)
        os.replace(temp, self.path)

    def clear(self):
        try:
            os.remove(self.path)
        except FileNotFoundError:
            pass
