"""VixSrc's documented Italian movie catalogue and player API."""
import base64
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin, urlparse, parse_qs
import requests
from bs4 import BeautifulSoup
from resources.lib.artwork import image_url

BASE = 'https://vixsrc.to'


def poster(identifier):
    page = 'https://www.themoviedb.org/movie/%s?language=it-IT' % int(identifier)
    try:
        response = requests.get(page, timeout=8)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        image = soup.select_one('meta[property="og:image"]')
        target = image_url(image.get('content', '') if image else '', page)
        parsed = urlparse(target)
        if parsed.scheme == 'https' and parsed.hostname in ('media.themoviedb.org', 'image.tmdb.org') and parsed.path.startswith('/t/p/'):
            return target
    except requests.RequestException:
        pass
    return ''


def api(path):
    try:
        response = requests.get(BASE + path, timeout=20)
        response.raise_for_status()
        if urlparse(response.url).scheme != 'https':
            raise RuntimeError('VixSrc ha reindirizzato la richiesta a una connessione non HTTPS.')
        return response.json()
    except (requests.RequestException, ValueError) as exc:
        raise RuntimeError('Impossibile caricare i dati di VixSrc.') from exc


def player(identifier):
    data = api('/api/movie/%s?lang=it' % int(identifier))
    target = urljoin(BASE, data.get('src', ''))
    if urlparse(target).hostname != 'vixsrc.to' or '/embed/' not in urlparse(target).path:
        raise RuntimeError('VixSrc non ha restituito un player valido.')
    return target


def movie_item(row):
    identifier = int(row['tmdb_id'])
    target = player(identifier)
    encoded = parse_qs(urlparse(target).query).get('t', [''])[0]
    try:
        title = base64.b64decode(encoded + '=' * (-len(encoded) % 4)).decode('utf-8').strip()
    except (ValueError, UnicodeError):
        title = ''
    return {'title': title or 'Film %s' % identifier, 'url': BASE + '/movie/%s?lang=it' % identifier,
            'year': '', 'type': 'movie', 'thumbnail': '', 'tmdb_id': identifier, 'imdb_id': row.get('imdb_id', '')}


class Provider:
    def __init__(self, profile, get_soup):
        self.profile, self.get_soup = profile, get_soup

    def catalog(self, page=1, kind=None, query=None, genre=None):
        if kind == 'tv' or genre:
            from resources.lib.cb01 import Provider as CB01
            items, following = CB01('https://cb01uno.wiki', self.get_soup).catalog(page, kind=kind, query=query, genre=genre)
            if genre:
                items = [item for item in items if item.get('type') == 'series']
            for item in items:
                item['source'] = 'https://cb01uno.wiki'
            return items, following
        rows = api('/api/list/movie/?lang=it')
        if not isinstance(rows, list):
            raise RuntimeError('Catalogo VixSrc non valido.')
        valid_rows = []
        for row in rows:
            try:
                if isinstance(row, dict) and int(row.get('tmdb_id')) > 0:
                    valid_rows.append(row)
            except (TypeError, ValueError):
                continue
        rows = valid_rows
        start = (page - 1) * 30
        os.makedirs(self.profile, exist_ok=True)
        def metadata(row):
            path = os.path.join(self.profile, 'vix-movie-%s.json' % int(row['tmdb_id']))
            try:
                with open(path, encoding='utf-8') as saved:
                    item = json.load(saved)
            except (OSError, ValueError):
                try:
                    item = movie_item(row)
                except (RuntimeError, ValueError, KeyError):
                    return None
            if not item.get('thumbnail') and time.time() - item.get('poster_checked', 0) >= 86400:
                item['thumbnail'] = poster(row['tmdb_id'])
                item['poster_checked'] = time.time()
            try:
                with open(path, 'w', encoding='utf-8') as saved:
                    json.dump(item, saved)
            except OSError:
                pass
            return item
        with ThreadPoolExecutor(max_workers=6) as workers:
            items = [item for item in workers.map(metadata, rows[start:start + 30]) if item]
        if query:
            # API exposes identifiers, not a global title-search endpoint.
            cached = []
            for name in os.listdir(self.profile):
                if name.startswith('vix-movie-') and name.endswith('.json'):
                    try:
                        with open(os.path.join(self.profile, name), encoding='utf-8') as saved:
                            cached.append(json.load(saved))
                    except (OSError, ValueError):
                        pass
            items = [item for item in cached if query.casefold() in item['title'].casefold()]
        return items, start + 30 < len(rows) if not query else False

    def genres(self):
        from resources.lib.cb01 import Provider as CB01
        return CB01('https://cb01uno.wiki', self.get_soup).genres()
