"""VixSrc's documented Italian movie catalogue and player API."""
import base64
import json
import os
import time
import re
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urljoin, urlparse, parse_qs
import requests
from bs4 import BeautifulSoup
from resources.lib.artwork import image_url

BASE = 'https://vixsrc.to'
MOVIE_GENRES = {28: 'Azione', 12: 'Avventura', 16: 'Animazione', 35: 'Commedia', 80: 'Crime', 99: 'Documentario',
                18: 'Dramma', 10751: 'Famiglia', 14: 'Fantasy', 36: 'Storia', 27: 'Horror', 10402: 'Musica',
                9648: 'Mistero', 10749: 'Romantico', 878: 'Fantascienza', 10770: 'Film TV', 53: 'Thriller', 10752: 'Guerra', 37: 'Western'}
TV_GENRES = {10759: 'Azione e avventura', 16: 'Animazione', 35: 'Commedia', 80: 'Crime', 99: 'Documentario',
             18: 'Dramma', 10751: 'Famiglia', 10762: 'Bambini', 9648: 'Mistero', 10763: 'Notizie', 10764: 'Reality',
             10765: 'Fantascienza e fantasy', 10766: 'Soap', 10767: 'Talk show', 10768: 'Guerra e politica', 37: 'Western'}


def poster(identifier, kind='movie'):
    page = 'https://www.themoviedb.org/%s/%s?language=it-IT' % (kind, int(identifier))
    try:
        response = requests.get(page, timeout=8)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        image = soup.select_one('meta[property="og:image"]')
        target = image_url(image.get('content', '') if image else '', page)
        parsed = urlparse(target)
        if parsed.scheme == 'https' and parsed.hostname in ('media.themoviedb.org', 'image.tmdb.org') and parsed.path.startswith('/t/p/'):
            return target
    except requests.RequestException:
        pass
    return ''


def api(path):
    try:
        response = requests.get(BASE + path, timeout=20)
        response.raise_for_status()
        if urlparse(response.url).scheme != 'https':
            raise RuntimeError('VixSrc ha reindirizzato la richiesta a una connessione non HTTPS.')
        return response.json()
    except (requests.RequestException, ValueError) as exc:
        raise RuntimeError('Impossibile caricare i dati di VixSrc.') from exc


def player(identifier, season=None, episode=None):
    path = '/api/movie/%s' % int(identifier) if season is None else '/api/tv/%s/%s/%s' % (int(identifier), int(season), int(episode))
    data = api(path + '?lang=it')
    target = urljoin(BASE, data.get('src', ''))
    if urlparse(target).hostname != 'vixsrc.to' or '/embed/' not in urlparse(target).path:
        raise RuntimeError('VixSrc non ha restituito un player valido.')
    return target


def movie_item(row):
    identifier = int(row['tmdb_id'])
    target = player(identifier)
    encoded = parse_qs(urlparse(target).query).get('t', [''])[0]
    try:
        title = base64.b64decode(encoded + '=' * (-len(encoded) % 4)).decode('utf-8').strip()
    except (ValueError, UnicodeError):
        title = ''
    return {'title': title or 'Film %s' % identifier, 'url': BASE + '/movie/%s?lang=it' % identifier,
            'year': '', 'type': 'movie', 'thumbnail': '', 'tmdb_id': identifier, 'imdb_id': row.get('imdb_id', '')}


class Provider:
    def __init__(self, profile, get_soup):
        self.profile, self.get_soup = profile, get_soup

    def search(self, query, kind='movie', page=1, genre=None):
        if kind not in ('movie', 'tv'):
            raise ValueError('Tipo di ricerca non valido.')
        if kind == 'tv':
            available = set(self.episode_index())
        else:
            rows = api('/api/list/movie/?lang=it')
            available = {row.get('tmdb_id') for row in rows if isinstance(row, dict) and isinstance(row.get('tmdb_id'), int)}
        params = {'language': 'it-IT', 'page': page}
        if genre is not None:
            genre = int(genre)
            if genre not in (TV_GENRES if kind == 'tv' else MOVIE_GENRES):
                raise ValueError('Genere non valido.')
            url = 'https://www.themoviedb.org/genre/%s/%s' % (genre, kind)
        else:
            url = 'https://www.themoviedb.org/search/' + kind
            params['query'] = query
        try:
            response = requests.get(url, params=params, timeout=15)
            response.raise_for_status()
        except requests.RequestException as exc:
            raise RuntimeError('Ricerca non disponibile. Riprova tra poco.') from exc
        soup = BeautifulSoup(response.text, 'html.parser')
        matches, seen = [], set()
        for link in soup.select('a[data-media-type="%s"][href]' % kind):
            heading = link.find('h2')
            match = re.match(r'/%s/(\d+)' % kind, urlparse(link['href']).path)
            if not heading or not match:
                continue
            identifier = int(match.group(1))
            if identifier in seen:
                continue
            seen.add(identifier)
            if identifier in available:
                title = heading.find('span') or heading
                matches.append({'title': title.get_text(' ', strip=True), 'url': BASE + '/%s/%s' % (kind, identifier),
                                'type': 'series' if kind == 'tv' else 'movie', 'year': '', 'tmdb_id': identifier, 'source': BASE})
        def artwork(item):
            item['thumbnail'] = poster(item['tmdb_id'], kind)
            return item
        with ThreadPoolExecutor(max_workers=6) as workers:
            results = list(workers.map(artwork, matches))
        return results, len(seen) >= 20

    def episode_index(self):
        os.makedirs(self.profile, exist_ok=True)
        path = os.path.join(self.profile, 'episodes.json')
        try:
            if time.time() - os.path.getmtime(path) < 3600:
                with open(path, encoding='utf-8') as saved:
                    rows = json.load(saved)
            else:
                rows = None
        except (OSError, ValueError):
            rows = None
        if rows is None:
            rows = api('/api/list/episode/?lang=it')
            if not isinstance(rows, list):
                raise RuntimeError('Elenco episodi VixSrc non valido.')
            try:
                with open(path, 'w', encoding='utf-8') as saved:
                    json.dump(rows, saved)
            except OSError:
                pass
        indexed = {}
        for row in rows:
            try:
                identifier, season, episode = int(row['tmdb_id']), int(row['s']), int(row['e'])
                if identifier > 0 and season >= 0 and episode > 0:
                    indexed.setdefault(identifier, set()).add((season, episode))
            except (KeyError, TypeError, ValueError):
                continue
        return indexed

    def series_catalog(self, page):
        index = self.episode_index()
        rows = api('/api/list/tv/?lang=it')
        if not isinstance(rows, list):
            raise RuntimeError('Catalogo serie VixSrc non valido.')
        rows = [row for row in rows if isinstance(row, dict) and row.get('tmdb_id') in index]
        start = (page - 1) * 30
        def metadata(row):
            identifier = row['tmdb_id']
            path = os.path.join(self.profile, 'vix-series-%s.json' % identifier)
            try:
                with open(path, encoding='utf-8') as saved:
                    return json.load(saved)
            except (OSError, ValueError):
                pass
            try:
                season, episode = min(index[identifier])
                target = player(identifier, season, episode)
                encoded = parse_qs(urlparse(target).query).get('t', [''])[0]
                title = base64.b64decode(encoded + '=' * (-len(encoded) % 4)).decode('utf-8').strip()
                item = {'title': title or 'Serie %s' % identifier, 'url': BASE + '/tv/%s' % identifier,
                        'type': 'series', 'year': '', 'thumbnail': poster(identifier, 'tv'), 'source': BASE}
                try:
                    with open(path, 'w', encoding='utf-8') as saved:
                        json.dump(item, saved)
                except OSError:
                    pass
                return item
            except (RuntimeError, ValueError, UnicodeError):
                return None
        with ThreadPoolExecutor(max_workers=6) as workers:
            items = [item for item in workers.map(metadata, rows[start:start + 30]) if item]
        return items, start + 30 < len(rows)

    def details(self, url):
        identifier = int(urlparse(url).path.rstrip('/').split('/')[-1])
        available = self.episode_index().get(identifier, set())
        return {'seasons': sorted({season for season, episode in available}), 'info': {'thumbnail': poster(identifier, 'tv')}}

    def episodes(self, url, season):
        identifier = int(urlparse(url).path.rstrip('/').split('/')[-1])
        return [{'title': 'Episodio %s' % episode, 'season': s, 'episode': episode,
                 'url': BASE + '/tv/%s/%s/%s?lang=it' % (identifier, s, episode), 'thumbnail': ''}
                for s, episode in sorted(self.episode_index().get(identifier, set())) if s == int(season)]

    def catalog(self, page=1, kind=None, query=None, genre=None):
        if genre:
            return self.search('', kind or 'movie', page, genre=genre)
        if kind == 'tv':
            return self.series_catalog(page)
        rows = api('/api/list/movie/?lang=it')
        if not isinstance(rows, list):
            raise RuntimeError('Catalogo VixSrc non valido.')
        valid_rows = []
        for row in rows:
            try:
                if isinstance(row, dict) and int(row.get('tmdb_id')) > 0:
                    valid_rows.append(row)
            except (TypeError, ValueError):
                continue
        rows = valid_rows
        start = (page - 1) * 30
        os.makedirs(self.profile, exist_ok=True)
        def metadata(row):
            path = os.path.join(self.profile, 'vix-movie-%s.json' % int(row['tmdb_id']))
            try:
                with open(path, encoding='utf-8') as saved:
                    item = json.load(saved)
            except (OSError, ValueError):
                try:
                    item = movie_item(row)
                except (RuntimeError, ValueError, KeyError):
                    return None
            if not item.get('thumbnail') and time.time() - item.get('poster_checked', 0) >= 86400:
                item['thumbnail'] = poster(row['tmdb_id'])
                item['poster_checked'] = time.time()
            try:
                with open(path, 'w', encoding='utf-8') as saved:
                    json.dump(item, saved)
            except OSError:
                pass
            return item
        with ThreadPoolExecutor(max_workers=6) as workers:
            items = [item for item in workers.map(metadata, rows[start:start + 30]) if item]
        if query:
            # API exposes identifiers, not a global title-search endpoint.
            cached = []
            for name in os.listdir(self.profile):
                if name.startswith('vix-movie-') and name.endswith('.json'):
                    try:
                        with open(os.path.join(self.profile, name), encoding='utf-8') as saved:
                            cached.append(json.load(saved))
                    except (OSError, ValueError):
                        pass
            items = [item for item in cached if query.casefold() in item['title'].casefold()]
        return items, start + 30 < len(rows) if not query else False

    def genres(self, kind='movie'):
        return [{'name': name, 'url': str(identifier)} for identifier, name in (TV_GENRES if kind == 'tv' else MOVIE_GENRES).items()]
