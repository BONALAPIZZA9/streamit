"""Session language choice and one-time audio selection at startup."""
import json
import re
import time
import xbmc
import xbmcgui

PENDING = 'streamit.pending.italian_audio'
LANGUAGE = 'streamit.session.audio_language'
LANGUAGES = [
    ('it', 'Italiano', 'Italian', ('it', 'ita'), ('italiano', 'italian', 'ita')),
    ('en', 'Inglese', 'English', ('en', 'eng'), ('inglese', 'english', 'eng')),
    ('es', 'Spagnolo', 'Spanish', ('es', 'spa'), ('spagnolo', 'spanish', 'español', 'spa')),
    ('fr', 'Francese', 'French', ('fr', 'fra', 'fre'), ('francese', 'french', 'français', 'fra')),
    ('de', 'Tedesco', 'German', ('de', 'deu', 'ger'), ('tedesco', 'german', 'deutsch', 'deu')),
    ('default', 'Originale / predefinita', 'mediadefault', (), ()),
]


def choose_language():
    choice = xbmcgui.Dialog().select('Scegli la lingua audio', [row[1] for row in LANGUAGES])
    if choice < 0:
        return False
    xbmcgui.Window(10000).setProperty(LANGUAGE, LANGUAGES[choice][0])
    return True


def selected_track(streams, key):
    language_info = next((row for row in LANGUAGES if row[0] == key), LANGUAGES[0])
    for stream in streams:
        language = str(stream.get('language', '')).lower().replace('_', '-')
        name = str(stream.get('name', '')).casefold()
        if language.split('-')[0] in language_info[3] or any(re.search(r'\b' + re.escape(word) + r'\b', name) for word in language_info[4]):
            return stream['index']
    return None


def prepare(stream_url):
    window = xbmcgui.Window(10000)
    key = window.getProperty(LANGUAGE) or 'it'
    language_info = next((row for row in LANGUAGES if row[0] == key), LANGUAGES[0])
    for setting, value in [('locale.audiolanguage', language_info[2]), ('videoplayer.preferdefaultflag', key == 'default')]:
        try:
            result = json.loads(xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.SetSettingValue',
                'params': {'setting': setting, 'value': value}})))
            if result.get('result') is not True:
                xbmc.log('[StreamIt] Audio preference rejected: ' + setting, xbmc.LOGWARNING)
        except (ValueError, RuntimeError):
            xbmc.log('[StreamIt] Cannot set audio preference: ' + setting, xbmc.LOGWARNING)
    if key == 'default':
        window.clearProperty(PENDING)
    else:
        window.setProperty(PENDING, json.dumps({
            'url': stream_url.split('|')[0], 'language': key, 'expires': time.time() + 90}))


def run():
    monitor, player, window = xbmc.Monitor(), xbmc.Player(), xbmcgui.Window(10000)
    active, started = '', 0
    while not monitor.abortRequested():
        raw = window.getProperty(PENDING)
        if raw:
            try:
                pending = json.loads(raw)
                if time.time() > pending['expires']:
                    if window.getProperty(PENDING) == raw:
                        window.clearProperty(PENDING)
                elif player.isPlayingVideo() and player.getPlayingFile().split('|')[0] == pending['url']:
                    if active != raw:
                        active, started = raw, time.time()
                    result = json.loads(xbmc.executeJSONRPC(json.dumps({
                        'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties',
                        'params': {'playerid': 1, 'properties': ['audiostreams']}})))
                    track = selected_track(result.get('result', {}).get('audiostreams', []), pending.get('language', 'it'))
                    if track is not None:
                        player.setAudioStream(track)
                    if track is not None or time.time() - started > 20:
                        if window.getProperty(PENDING) == raw:
                            window.clearProperty(PENDING)
            except (ValueError, KeyError, TypeError, RuntimeError):
                pass  # The player can disappear between the checks during stop/skip.
        if monitor.waitForAbort(0.25):
            break
