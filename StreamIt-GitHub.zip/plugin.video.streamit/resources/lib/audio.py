"""Session language choice and one-time audio selection at startup."""
import json
import re
import time
import xbmc
import xbmcgui
import xbmcaddon

PENDING = 'streamit.pending.italian_audio'
LANGUAGES = [
    ('it', 'Italiano', 'Italian', ('it', 'ita'), ('italiano', 'italian', 'ita')),
    ('en', 'Inglese', 'English', ('en', 'eng'), ('inglese', 'english', 'eng')),
]


def choose_language():
    addon = xbmcaddon.Addon('plugin.video.streamit')
    if addon.getSetting('audio_language_confirmed') == 'true':
        return True
    choice = xbmcgui.Dialog().select('Scegli la lingua audio', [row[1] for row in LANGUAGES])
    if choice < 0:
        return False
    addon.setSetting('audio_language', str(choice))
    addon.setSetting('audio_language_confirmed', 'true')
    return True


def selected_track(streams, key):
    language_info = next((row for row in LANGUAGES if row[0] == key), LANGUAGES[0])
    for stream in streams:
        language = str(stream.get('language', '')).lower().replace('_', '-')
        name = str(stream.get('name', '')).casefold()
        if language.split('-')[0] in language_info[3] or any(re.search(r'\b' + re.escape(word) + r'\b', name) for word in language_info[4]):
            return stream['index']
    return None


def prepare(stream_url, title=''):
    window = xbmcgui.Window(10000)
    addon = xbmcaddon.Addon('plugin.video.streamit')
    key = 'en' if addon.getSetting('audio_language') == '1' else 'it'
    language_info = next((row for row in LANGUAGES if row[0] == key), LANGUAGES[0])
    for setting, value in [('locale.audiolanguage', language_info[2]), ('videoplayer.preferdefaultflag', False)]:
        try:
            result = json.loads(xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.SetSettingValue',
                'params': {'setting': setting, 'value': value}})))
            if result.get('result') is not True:
                xbmc.log('[StreamIt] Audio preference rejected: ' + setting, xbmc.LOGWARNING)
        except (ValueError, RuntimeError):
            xbmc.log('[StreamIt] Cannot set audio preference: ' + setting, xbmc.LOGWARNING)
    window.setProperty(PENDING, json.dumps({
        'url': stream_url.split('|')[0], 'title': title, 'language': key,
        'expires': time.time() + 90}))


class AudioPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.started = False

    def onAVStarted(self):
        self.started = True

    def onPlayBackStopped(self):
        self.started = False

    def onPlayBackEnded(self):
        self.started = False


def run():
    from resources.lib.updates import RepositoryUpdates
    monitor, player, window = xbmc.Monitor(), AudioPlayer(), xbmcgui.Window(10000)
    updates = RepositoryUpdates()
    active, started = '', 0
    while not monitor.abortRequested():
        updates.tick(player.isPlaying())
        raw = window.getProperty(PENDING)
        if raw:
            try:
                pending = json.loads(raw)
                if time.time() > pending['expires']:
                    if window.getProperty(PENDING) == raw:
                        window.clearProperty(PENDING)
                elif player.isPlayingVideo() and (
                    player.getPlayingFile().split('|')[0] == pending['url'] or
                    (player.started and pending.get('title') and xbmc.getInfoLabel('VideoPlayer.Title') == pending['title'])):
                    if active != raw:
                        active, started = raw, time.time()
                    result = json.loads(xbmc.executeJSONRPC(json.dumps({
                        'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties',
                        'params': {'playerid': 1, 'properties': ['audiostreams']}})))
                    streams = result.get('result', {}).get('audiostreams', [])
                    if not streams:
                        streams = [{'index': i, 'name': name, 'language': name}
                                   for i, name in enumerate(player.getAvailableAudioStreams())]
                    track = selected_track(streams, pending.get('language', 'it'))
                    if track is not None:
                        player.setAudioStream(track)
                    if track is not None or time.time() - started > 10:
                        if track is None:
                            label = 'inglese' if pending.get('language') == 'en' else 'italiana'
                            xbmcgui.Dialog().notification('StreamIt', 'Traccia ' + label + ' non disponibile o non identificata.', time=4000)
                        if window.getProperty(PENDING) == raw:
                            window.clearProperty(PENDING)
                        player.started = False
            except (ValueError, KeyError, TypeError, RuntimeError):
                pass  # The player can disappear between the checks during stop/skip.
        if monitor.waitForAbort(0.25):
            break
