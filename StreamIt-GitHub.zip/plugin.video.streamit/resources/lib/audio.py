"""Italian audio preference and one-time selection at playback startup."""
import json
import re
import time
import xbmc
import xbmcgui

PENDING = 'streamit.pending.italian_audio'


def italian_track(streams):
    for stream in streams:
        language = str(stream.get('language', '')).lower().replace('_', '-')
        name = str(stream.get('name', '')).casefold()
        if language.split('-')[0] in ('it', 'ita') or re.search(r'\b(italiano|italian|ita)\b', name):
            return stream['index']
    return None


def prepare(stream_url):
    # Set before resolving the video, so Kodi chooses Italian from the first frame.
    for setting, value in [('locale.audiolanguage', 'Italian'), ('videoplayer.preferdefaultflag', False)]:
        try:
            result = json.loads(xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.SetSettingValue',
                'params': {'setting': setting, 'value': value}})))
            if result.get('result') is not True:
                xbmc.log('[StreamIt] Audio preference rejected: ' + setting, xbmc.LOGWARNING)
        except (ValueError, RuntimeError):
            xbmc.log('[StreamIt] Cannot set audio preference: ' + setting, xbmc.LOGWARNING)
    xbmcgui.Window(10000).setProperty(PENDING, json.dumps({
        'url': stream_url.split('|')[0], 'expires': time.time() + 90}))


def run():
    monitor, player, window = xbmc.Monitor(), xbmc.Player(), xbmcgui.Window(10000)
    active, started = '', 0
    while not monitor.abortRequested():
        raw = window.getProperty(PENDING)
        if raw:
            try:
                pending = json.loads(raw)
                if time.time() > pending['expires']:
                    if window.getProperty(PENDING) == raw:
                        window.clearProperty(PENDING)
                elif player.isPlayingVideo() and player.getPlayingFile().split('|')[0] == pending['url']:
                    if active != raw:
                        active, started = raw, time.time()
                    result = json.loads(xbmc.executeJSONRPC(json.dumps({
                        'jsonrpc': '2.0', 'id': 1, 'method': 'Player.GetProperties',
                        'params': {'playerid': 1, 'properties': ['audiostreams']}})))
                    track = italian_track(result.get('result', {}).get('audiostreams', []))
                    if track is not None:
                        player.setAudioStream(track)
                    if track is not None or time.time() - started > 20:
                        if window.getProperty(PENDING) == raw:
                            window.clearProperty(PENDING)
            except (ValueError, KeyError, TypeError, RuntimeError):
                pass  # The player can disappear between the checks during stop/skip.
        if monitor.waitForAbort(0.25):
            break
