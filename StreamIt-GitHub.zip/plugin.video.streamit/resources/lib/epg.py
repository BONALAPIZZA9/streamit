"""Italian XMLTV guide cached in the local profile."""
import io
import json
import lzma
import os
import time
from datetime import datetime
import xml.etree.ElementTree as ET
import requests

EPG_URL = 'https://epg-guide.com/wltv.xz'


def timestamp(value):
    parts = value.strip().split()
    return datetime.strptime(parts[0] + ' ' + (parts[1] if len(parts) > 1 else '+0000'), '%Y%m%d%H%M%S %z').timestamp()


def parse(data, now=None):
    now = time.time() if now is None else now
    result = {}
    for event, node in ET.iterparse(io.BytesIO(data), events=('end',)):
        if node.tag != 'programme':
            continue
        try:
            start, stop = timestamp(node.get('start', '')), timestamp(node.get('stop', ''))
            if stop > now and start < now + 86400 and start < stop:
                result.setdefault(node.get('channel', ''), []).append({'start': start, 'stop': stop,
                    'title': node.findtext('title') or 'Programma', 'description': node.findtext('desc') or ''})
        except (ValueError, IndexError):
            pass
        node.clear()
    for rows in result.values():
        rows.sort(key=lambda row: row['start'])
    return result


def load(profile):
    path = os.path.join(profile, 'tv-guide.json')
    cached = None
    try:
        with open(path, encoding='utf-8') as saved:
            cached = json.load(saved)
        if isinstance(cached, dict) and time.time() - os.path.getmtime(path) < 7200:
            return cached
    except (OSError, ValueError):
        pass
    try:
        response = requests.get(EPG_URL, timeout=20)
        response.raise_for_status()
        if len(response.content) > 10 * 1024 * 1024:
            raise ValueError('EPG troppo grande')
        data = lzma.LZMADecompressor(memlimit=128 * 1024 * 1024).decompress(response.content, max_length=64 * 1024 * 1024)
        result = parse(data)
    except (requests.RequestException, lzma.LZMAError, ET.ParseError, ValueError) as exc:
        if isinstance(cached, dict):
            return cached
        raise RuntimeError('Guida TV non disponibile. I canali restano utilizzabili; riprova più tardi.') from exc
    try:
        os.makedirs(profile, exist_ok=True)
        with open(path + '.tmp', 'w', encoding='utf-8') as saved:
            json.dump(result, saved)
        os.replace(path + '.tmp', path)
    except OSError:
        pass
    return result


def schedule(channel, guide, now=None):
    now = time.time() if now is None else now
    return [row for row in guide.get(channel.get('id', ''), []) if row['stop'] > now]


def info(channel, guide, now=None):
    now = time.time() if now is None else now
    rows = schedule(channel, guide, now)
    current = next((row for row in rows if row['start'] <= now < row['stop']), None)
    following = next((row for row in rows if row['start'] > now), None)
    lines = []
    for label, row in [('Ora', current), ('Dopo', following)]:
        if row:
            lines.append(label + ' ' + datetime.fromtimestamp(row['start']).strftime('%H:%M') + ': ' + row['title'])
    return '\n'.join(lines)
