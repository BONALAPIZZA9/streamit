"""Separate live-TV listing from the public IPTV Italia playlist."""
import re
import hashlib
from urllib.parse import urljoin, urlparse, quote
import requests

PLAYLIST_URL = 'https://raw.githubusercontent.com/Tundrak/IPTV-Italia/main/iptvitaplus.m3u'
ALTERNATIVE_URL = 'https://iptv-org.github.io/iptv/index.m3u'
PLAYLISTS = {'italia': PLAYLIST_URL, 'alternative': ALTERNATIVE_URL}


def parse_playlist(text, base_url=PLAYLIST_URL):
    channels, pending = [], None
    for line in text.lstrip('\ufeff').splitlines():
        line = line.strip()
        if line.startswith('#EXTINF:'):
            # The title separator can follow commas inside quoted attributes.
            match = re.match(r'#EXTINF:(?:[^",]|"[^"]*")*,(.*)$', line)
            name = match.group(1).strip() if match else ''
            attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', line))
            pending = {'name': name or attrs.get('tvg-name', 'Canale'),
                       'logo': attrs.get('tvg-logo', ''), 'headers': {}}
        elif pending and line.startswith('#EXTVLCOPT:'):
            option, _, value = line[len('#EXTVLCOPT:'):].partition('=')
            header = {'http-user-agent': 'User-Agent', 'http-referrer': 'Referer'}.get(option)
            if header and value:
                pending['headers'][header] = value
        elif line and not line.startswith('#'):
            if pending:
                url = urljoin(base_url, line)
                if urlparse(url.split('|')[0]).scheme in ('http', 'https'):
                    pending['url'] = url
                    channels.append(pending)
            pending = None
    return channels


def channel_key(channel):
    return hashlib.sha256((channel['name'] + '\n' + channel['url']).encode('utf-8')).hexdigest()[:24]


def load_channels(playlist='italia', fallback=True):
    if playlist not in PLAYLISTS:
        raise ValueError('Playlist IPTV non valida.')
    try:
        response = requests.get(PLAYLISTS[playlist], timeout=20)
        response.raise_for_status()
        channels = parse_playlist(response.content.decode('utf-8-sig', errors='replace'), response.url)
        if not channels:
            raise RuntimeError('La playlist IPTV non contiene canali disponibili.')
    except requests.RequestException as exc:
        if playlist == 'italia' and fallback:
            return load_channels('alternative', fallback=False)
        raise RuntimeError('Impossibile caricare la playlist IPTV. Verifica la connessione e riprova.') from exc
    except RuntimeError:
        if playlist == 'italia' and fallback:
            return load_channels('alternative', fallback=False)
        raise
    for channel in channels:
        channel['playlist'] = playlist
    return channels


def playback_url(channel):
    url = channel['url']
    if channel['headers'] and '|' not in url:
        url += '|' + '&'.join(quote(k) + '=' + quote(v, safe='') for k, v in channel['headers'].items())
    return url
