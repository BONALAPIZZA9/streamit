"""Separate live-TV listing from the public IPTV Italia playlist."""
import re
from urllib.parse import urljoin, urlparse, quote
import requests

PLAYLIST_URL = 'https://raw.githubusercontent.com/Tundrak/IPTV-Italia/main/iptvitaplus.m3u'


def parse_playlist(text, base_url=PLAYLIST_URL):
    channels, pending = [], None
    for line in text.lstrip('\ufeff').splitlines():
        line = line.strip()
        if line.startswith('#EXTINF:'):
            # The title separator can follow commas inside quoted attributes.
            match = re.match(r'#EXTINF:(?:[^",]|"[^"]*")*,(.*)$', line)
            name = match.group(1).strip() if match else ''
            attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', line))
            pending = {'name': name or attrs.get('tvg-name', 'Canale'),
                       'logo': attrs.get('tvg-logo', ''), 'headers': {}}
        elif pending and line.startswith('#EXTVLCOPT:'):
            option, _, value = line[len('#EXTVLCOPT:'):].partition('=')
            header = {'http-user-agent': 'User-Agent', 'http-referrer': 'Referer'}.get(option)
            if header and value:
                pending['headers'][header] = value
        elif line and not line.startswith('#'):
            if pending:
                url = urljoin(base_url, line)
                if urlparse(url.split('|')[0]).scheme in ('http', 'https'):
                    pending['url'] = url
                    channels.append(pending)
            pending = None
    return channels


def load_channels():
    try:
        response = requests.get(PLAYLIST_URL, timeout=20)
        response.raise_for_status()
        channels = parse_playlist(response.content.decode('utf-8-sig', errors='replace'), response.url)
    except requests.RequestException as exc:
        raise RuntimeError('Impossibile caricare IPTV Italia. Verifica la connessione e riprova.') from exc
    if not channels:
        raise RuntimeError('La playlist IPTV non contiene canali disponibili.')
    return channels


def playback_url(channel):
    url = channel['url']
    if channel['headers'] and '|' not in url:
        url += '|' + '&'.join(quote(k) + '=' + quote(v, safe='') for k, v in channel['headers'].items())
    return url
