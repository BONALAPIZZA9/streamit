# -*- coding: utf-8 -*-
# File obbligatorio per rendere 'lib' un package Python
