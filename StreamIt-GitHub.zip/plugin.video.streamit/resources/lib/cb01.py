"""Catalogo CB01 e collegamenti pubblicati nelle schede."""
import re
from resources.lib.artwork import best_image
from urllib.parse import urljoin, urlparse, urlencode, parse_qs


def supports(soup):
    title = soup.title.get_text().upper() if soup.title else ''
    return 'CB01' in title and bool(soup.select_one('.card-title a, .sequex-posts-info'))


def compact_series(items):
    result, seen = [], set()
    for item in items:
        key = item['url'].split('#')[0].rstrip('/')
        if key in seen:
            continue
        seen.add(key)
        title = re.split(r'\s*[–—-]\s*(?:(?:stagion[ei]|episodi[oa]?)\b|\d+\s*[x×]\s*\d+|S\d+\s*E\d+)', item['title'], maxsplit=1, flags=re.I)[0]
        title = re.sub(r'\s*(?:[–—-]\s*)?(?:\[(?:ITA|SUB ITA|HD|FHD|COMPLETA)\]|(?:ITA|SUB ITA|COMPLETA))\s*$', '', title, flags=re.I).strip()
        result.append(dict(item, title=title, url=key + '/'))
    return result


def links(node, base):
    result, seen = [], set()
    for a in node.select('a[href]'):
        label = a.get_text(' ', strip=True)
        url = urljoin(base, a['href'])
        if label.lower() not in ('maxstream', 'mixdrop', 'streamtape', 'voe', 'doodstream'):
            continue
        if urlparse(url).scheme not in ('http', 'https') or url in seen:
            continue
        seen.add(url)
        result.append({'name': label, 'url': url})
    return result


class Provider:
    def __init__(self, base, get_soup):
        self.base = base.rstrip('/')
        self.get_soup = get_soup

    def catalog(self, page=1, kind=None, query=None, genre=None):
        url = genre or self.base + ('/serietv/' if kind == 'tv' else '/')
        if page > 1:
            url = url.rstrip('/') + '/page/%s/' % page
        soup = self.get_soup(url, params={'s': query} if query else None)
        items, seen = [], set()
        for card in soup.select('.card.mp-post'):
            a = card.select_one('.card-title a[href]')
            if not a:
                continue
            target = urljoin(url, a['href'])
            if target in seen:
                continue
            seen.add(target)
            title = a.get_text(' ', strip=True)
            image = card.select_one('img')
            thumbnail = best_image(image, url)
            year = re.search(r'\b(19\d{2}|20\d{2})\b', title)
            items.append({'title': title, 'url': target, 'thumbnail': thumbnail,
                          'type': 'series' if '/serietv/' in urlparse(target).path else 'movie',
                          'year': year.group(1) if year else ''})
        next_path = urlparse(url).path.rstrip('/')
        next_path = re.sub(r'/page/\d+$', '', next_path) + '/page/%s/' % (page + 1)
        has_next = any(urlparse(urljoin(url, a['href'])).path == next_path for a in soup.select('a[href]'))
        return compact_series(items) if kind == 'tv' else items, has_next

    def genres(self):
        soup = self.get_soup(self.base + '/')
        result, seen = [], set()
        for a in soup.select('a[href]'):
            url = urljoin(self.base, a['href'])
            path = urlparse(url).path
            if not ('/category/film-' in path or '/category/film/' in path) or url in seen:
                continue
            seen.add(url)
            result.append({'name': a.get_text(' ', strip=True), 'url': url})
        return result

    def _episodes(self, soup, url):
        result = {}
        for row in soup.select('p'):
            text = row.get_text(' ', strip=True)
            match = re.match(r'\s*(\d+)\s*[x×]\s*(\d+)\b', text, re.I)
            if not match or not links(row, url):
                continue
            season, episode = map(int, match.groups())
            key = (season, episode)
            if key not in result:
                result[key] = {'title': 'Episodio %s' % episode, 'season': season, 'episode': episode,
                               'url': url.split('#')[0] + '#'+urlencode({'season': season, 'episode': episode}),
                               'thumbnail': '', 'sources': []}
            result[key]['sources'].extend(links(row, url))
        return result

    def details(self, url):
        episodes = self._episodes(self.get_soup(url), url)
        return {'seasons': sorted({key[0] for key in episodes}), 'info': {}}

    def episodes(self, url, season):
        episodes = self._episodes(self.get_soup(url), url)
        return [item for key, item in sorted(episodes.items()) if key[0] == season]

    def streams(self, url):
        parsed = urlparse(url)
        soup = self.get_soup(url.split('#')[0])
        selected = parse_qs(parsed.fragment)
        if 'season' in selected and 'episode' in selected:
            key = (int(selected['season'][0]), int(selected['episode'][0]))
            return self._episodes(soup, url).get(key, {}).get('sources', [])
        return links(soup, url)
