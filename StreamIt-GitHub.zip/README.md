# StreamIt — pubblicazione GitHub/Kodi

Questo pacchetto contiene StreamIt 1.6.0 e la procedura per pubblicare un repository Kodi su GitHub Pages. Non è ancora online.

## Prima pubblicazione

1. Crea un repository GitHub pubblico, ad esempio `streamit`.
2. Carica il contenuto di questa cartella nella radice, includendo `.github/workflows/pages.yml`.
3. Nel repository apri **Settings → Pages → Source → GitHub Actions**.
4. Apri **Actions → Pubblica repository Kodi → Run workflow**.
5. Al termine, apri il link mostrato dalla pubblicazione: è l'indirizzo da aggiungere in Kodi.

Non caricare soltanto lo ZIP di questo pacchetto: i file devono essere estratti nella radice del repository.

## Installazione in Kodi

1. Gestione file → Aggiungi sorgente → indirizzo GitHub Pages pubblicato.
2. Add-on → Installa da file ZIP → scegli la sorgente → `repository.streamit-1.0.0.zip`.
3. Installa da repository → StreamIt Repository → Add-on video → StreamIt.
4. Se Kodi lo richiede, abilita l'installazione da origini sconosciute.

## Aggiornamenti

Aggiorna i sorgenti e incrementa la versione in `plugin.video.streamit/addon.xml` prima di pubblicare una nuova versione. Ogni modifica a main/master rigenera sito, ZIP e indice. Gli utenti ricevono gli aggiornamenti secondo le impostazioni di Kodi.

## Controllo locale

`python build_repository.py --base-url https://example.invalid/streamit/`

L'indirizzo sopra è solo per verificare la generazione; non è un download pubblico. Il workflow usa automaticamente l'indirizzo reale di GitHub Pages.

Il repository distribuisce l'addon; non cambia i limiti di compatibilità dei siti e dei lettori esterni descritti nel README dell'addon.
